# -*- coding: utf-8 -*-
"""APEX Exchange Native — fixed engine + cleaner professional UI."""
from __future__ import annotations
import os
import threading

from kivy.app import App
from kivy.clock import Clock
from kivy.core.window import Window
from kivy.graphics import Color, RoundedRectangle, Rectangle, Line
from kivy.metrics import dp
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.button import Button
from kivy.uix.gridlayout import GridLayout
from kivy.uix.label import Label
from kivy.uix.screenmanager import Screen, ScreenManager, NoTransition
from kivy.uix.scrollview import ScrollView
from kivy.uix.spinner import Spinner
from kivy.uix.textinput import TextInput
from kivy.uix.widget import Widget

from apex import market_apis as mapi
from apex import coarena_ai as cai
from apex import storage as db
from apex import analysis as core_an
from apex import learning as learn

# Refined dark exchange palette
# Pure black / white / sky blue premium palette
C_BG = (0.0, 0.0, 0.0, 1)              # pure black
C_CARD = (0.06, 0.07, 0.09, 1)
C_CARD2 = (0.10, 0.12, 0.15, 1)
C_LINE = (0.18, 0.22, 0.28, 1)
C_TEXT = (1.0, 1.0, 1.0, 1)            # pure white
C_MUTED = (0.62, 0.68, 0.75, 1)
C_GREEN = (0.10, 0.85, 0.55, 1)
C_RED = (1.0, 0.32, 0.40, 1)
C_GOLD = (1.0, 0.82, 0.25, 1)
C_BLUE = (0.35, 0.70, 1.0, 1)          # sky / asmani blue
C_BLUE2 = (0.20, 0.55, 0.95, 1)
C_CYAN = (0.40, 0.90, 1.0, 1)

Window.clearcolor = C_BG
Window.softinput_mode = "below_target"

MODELS = [
    "claude-sonnet-5-5", "claude-opus-5-5", "claude-haiku-5-5",
    "gemini-4-carbon", "gemini-3-8-flash", "grok-4-7",
    "kimi-k3-1-pro", "deepseek-v4-1-flash-1017", "qwen3-8-2-4t-a95b",
]

def load_prefs():
    return {
        "default_leverage": db.get_setting("pref_lev", "5"),
        "default_margin": db.get_setting("pref_margin", "10"),
        "min_conviction": db.get_setting("pref_min_conv", "4"),
        "risk_note": db.get_setting("pref_risk", "1"),
        "prefer_tf": db.get_setting("pref_tf", "1hour"),
    }

def save_prefs(d):
    for k, v in d.items():
        db.set_setting(k if k.startswith("pref_") else "pref_" + k.replace("default_", "").replace("min_", "min_"), str(v))
    # normalize keys
    mapping = {
        "default_leverage": "pref_lev",
        "default_margin": "pref_margin",
        "min_conviction": "pref_min_conv",
        "risk_note": "pref_risk",
        "prefer_tf": "pref_tf",
    }
    for k, v in d.items():
        db.set_setting(mapping.get(k, "pref_" + k), str(v))

COINS = ["BTC", "ETH", "SOL", "XRP", "DOGE", "BNB", "ADA", "LINK", "AVAX", "DOT"]


def money(x) -> str:
    try:
        return f"{float(x):,.2f}"
    except Exception:
        return "—"


def pxfmt(x) -> str:
    try:
        v = float(x)
        if v >= 1000:
            return f"{v:,.2f}"
        if v >= 1:
            return f"{v:,.4f}"
        return f"{v:.8g}"
    except Exception:
        return "—"


class SoftButton(Button):
    """Touch-friendly rounded button with press dim."""
    def __init__(self, bg=C_CARD2, fg=C_TEXT, radius=14, **kwargs):
        kwargs.setdefault("size_hint_y", None)
        kwargs.setdefault("height", dp(48))
        super().__init__(
            background_normal="", background_down="",
            background_color=(0, 0, 0, 0), color=fg, bold=True,
            font_size=dp(14), **kwargs,
        )
        self._bg = bg
        self._radius = radius
        with self.canvas.before:
            self._col = Color(*bg)
            self._rect = RoundedRectangle(radius=[dp(radius)])
        self.bind(pos=self._sync, size=self._sync)
        self.bind(state=self._on_state)

    def _sync(self, *a):
        self._rect.pos = self.pos
        self._rect.size = self.size

    def _on_state(self, *a):
        if self.state == "down":
            r, g, b, al = self._bg
            self._col.rgba = (r * 0.75, g * 0.75, b * 0.75, al)
        else:
            self._col.rgba = self._bg

    def set_bg(self, rgba):
        self._bg = rgba
        self._col.rgba = rgba


class SoftInput(TextInput):
    def __init__(self, **kwargs):
        kwargs.setdefault("multiline", False)
        kwargs.setdefault("size_hint_y", None)
        kwargs.setdefault("height", dp(48))
        kwargs.setdefault("padding", [dp(16), dp(14), dp(16), dp(14)])
        kwargs.setdefault("foreground_color", C_TEXT)
        kwargs.setdefault("cursor_color", C_BLUE)
        kwargs.setdefault("font_size", dp(15))
        kwargs.setdefault("hint_text_color", (0.45, 0.5, 0.55, 1))
        super().__init__(
            background_normal="", background_active="",
            background_color=C_CARD2, **kwargs,
        )
        with self.canvas.after:
            self._border_c = Color(*C_LINE)
            self._border = Line(rounded_rectangle=(0, 0, 10, 10, dp(12)), width=1.1)
        self.bind(pos=self._b, size=self._b)

    def _b(self, *a):
        self._border.rounded_rectangle = (self.x, self.y, self.width, self.height, dp(12))


class CardBox(BoxLayout):
    def __init__(self, accent=None, **kwargs):
        kwargs.setdefault("orientation", "vertical")
        kwargs.setdefault("padding", [dp(16), dp(14)])
        kwargs.setdefault("spacing", dp(10))
        super().__init__(**kwargs)
        with self.canvas.before:
            Color(*C_CARD)
            self._r = RoundedRectangle(radius=[dp(18)])
            if accent:
                Color(*accent)
                self._acc = RoundedRectangle(radius=[dp(3)])
            else:
                self._acc = None
            Color(*C_LINE)
            self._bd = Line(rounded_rectangle=(0, 0, 10, 10, dp(18)), width=1)
        self.bind(pos=self._sync, size=self._sync)

    def _sync(self, *a):
        self._r.pos = self.pos
        self._r.size = self.size
        self._bd.rounded_rectangle = (self.x, self.y, self.width, self.height, dp(18))
        if self._acc is not None:
            self._acc.pos = (self.x, self.y + dp(8))
            self._acc.size = (dp(4), self.height - dp(16))


class Title(Label):
    def __init__(self, text, size=20, color=C_TEXT, **kw):
        super().__init__(
            text=text, color=color, bold=True, font_size=dp(size),
            size_hint_y=None, height=dp(size + 16), halign="right", valign="middle", **kw,
        )
        self.bind(size=lambda *_: setattr(self, "text_size", (self.width, self.height)))


class Sub(Label):
    def __init__(self, text="", **kw):
        kw.setdefault("size_hint_y", None)
        kw.setdefault("height", dp(22))
        super().__init__(text=text, color=C_MUTED, font_size=dp(12), **kw)


class SectionLabel(Label):
    def __init__(self, text="", **kw):
        super().__init__(
            text=text, color=C_BLUE, bold=True, font_size=dp(13),
            size_hint_y=None, height=dp(28), **kw,
        )


class CandleChart(Widget):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.candles = []
        self.bind(pos=self.redraw, size=self.redraw)

    def set_candles(self, candles):
        self.candles = candles or []
        self.redraw()

    def redraw(self, *a):
        self.canvas.clear()
        with self.canvas:
            Color(*C_CARD)
            RoundedRectangle(pos=self.pos, size=self.size, radius=[dp(14)])
        if not self.candles or self.width < 20:
            return
        data = self.candles[-60:]
        mn = min(c["low"] for c in data)
        mx = max(c["high"] for c in data)
        if mx <= mn:
            mx = mn + 1
        n = len(data)
        w = self.width / n
        bw = max(w * 0.55, 1.5)
        for i, c in enumerate(data):
            x = self.x + i * w + (w - bw) / 2

            def Y(v):
                return self.y + 8 + (v - mn) / (mx - mn) * (self.height - 16)

            up = c["close"] >= c["open"]
            with self.canvas:
                Color(*(C_GREEN if up else C_RED))
                Line(points=[x + bw / 2, Y(c["low"]), x + bw / 2, Y(c["high"])], width=1.1)
                y0, y1 = sorted([Y(c["open"]), Y(c["close"])])
                RoundedRectangle(pos=(x, y0), size=(bw, max(y1 - y0, 1.5)), radius=[1])


class HeaderBar(BoxLayout):
    def __init__(self, **kwargs):
        super().__init__(size_hint_y=None, height=dp(58), padding=[dp(16), dp(8)], spacing=dp(10), **kwargs)
        with self.canvas.before:
            Color(*C_BG)
            self._bg = Rectangle()
            Color(*C_LINE)
            self._ln = Line(width=1)
        self.bind(pos=self._s, size=self._s)
        self.logo = Label(text="APEX", color=C_BLUE, bold=True, font_size=dp(20), size_hint_x=0.28)
        self.eq = Label(text="Equity $—", color=C_TEXT, font_size=dp(13), bold=True, halign="left", valign="middle")
        self.eq.bind(size=lambda *_: setattr(self.eq, "text_size", self.eq.size))
        self.add_widget(self.logo)
        self.add_widget(self.eq)

    def _s(self, *a):
        self._bg.pos = self.pos
        self._bg.size = self.size
        self._ln.points = [self.x, self.y, self.right, self.y]

    def set_equity(self, equity, upnl=0):
        sign = "+" if upnl >= 0 else ""
        self.eq.text = f"Equity ${money(equity)}  ({sign}{money(upnl)})"
        self.eq.color = C_GREEN if upnl >= 0 else C_RED


class TradeScreen(Screen):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        root = BoxLayout(orientation="vertical", padding=[dp(14), dp(10)], spacing=dp(12))
        root.add_widget(Title("معامله", 22, C_BLUE))

        # price card
        pc = CardBox(size_hint_y=None, height=dp(142), accent=C_BLUE)
        row = BoxLayout(size_hint_y=None, height=dp(46), spacing=dp(8))
        self.sym = SoftInput(text="BTC", hint_text="نماد")
        self.sym.size_hint_x = 0.4
        go = SoftButton(text="قیمت", bg=C_GOLD, fg=(0.05, 0.05, 0.05, 1), size_hint_x=0.25)
        go.bind(on_release=lambda *_: self.fetch_price())
        self.order_type = Spinner(
            text="بازار", values=("بازار", "حد", "حد ضرر"),
            size_hint_x=0.35, background_color=C_CARD2, color=C_TEXT,
        )
        row.add_widget(self.sym)
        row.add_widget(go)
        row.add_widget(self.order_type)
        self.price_lbl = Label(text="—", color=C_GOLD, bold=True, font_size=dp(28), size_hint_y=None, height=dp(36))
        self.meta = Sub("منبع — · ۲۴س —")
        pc.add_widget(row)
        pc.add_widget(self.price_lbl)
        pc.add_widget(self.meta)
        root.add_widget(pc)

        # side buttons
        side = BoxLayout(size_hint_y=None, height=dp(48), spacing=dp(10))
        self.btn_long = SoftButton(text="خرید  Long", bg=C_GREEN, fg=(0.02, 0.08, 0.05, 1))
        self.btn_short = SoftButton(text="فروش  Short", bg=C_CARD2, fg=C_TEXT)
        self.side = "LONG"
        self.btn_long.bind(on_release=lambda *_: self.set_side("LONG"))
        self.btn_short.bind(on_release=lambda *_: self.set_side("SHORT"))
        side.add_widget(self.btn_long)
        side.add_widget(self.btn_short)
        root.add_widget(side)

        # fields
        g = GridLayout(cols=2, spacing=dp(8), size_hint_y=None, height=dp(100))
        self.entry = SoftInput(hint_text="قیمت ورود", input_filter="float")
        prefs0 = load_prefs()
        self.lev = SoftInput(text=str(prefs0.get("default_leverage") or "5"), hint_text="اهرم", input_filter="float")
        self.margin = SoftInput(text=str(prefs0.get("default_margin") or "10"), hint_text="مارجین $", input_filter="float")
        self.trail = SoftInput(text="0", hint_text="تریل %", input_filter="float")
        for w in (self.entry, self.lev, self.margin, self.trail):
            g.add_widget(w)
        root.add_widget(g)
        g2 = GridLayout(cols=2, spacing=dp(8), size_hint_y=None, height=dp(50))
        self.tp1 = SoftInput(hint_text="حد سود", input_filter="float")
        self.sl = SoftInput(hint_text="حد ضرر", input_filter="float")
        g2.add_widget(self.tp1)
        g2.add_widget(self.sl)
        root.add_widget(g2)

        open_btn = SoftButton(text="ثبت سفارش", bg=C_GREEN, fg=(0.02, 0.08, 0.05, 1), size_hint_y=None, height=dp(52))
        open_btn.bind(on_release=lambda *_: self.open_pos())
        root.add_widget(open_btn)
        an_btn = SoftButton(text="تحلیل هسته (داده+سیگنال)", bg=C_BLUE, fg=(1, 1, 1, 1), size_hint_y=None, height=dp(46))
        an_btn.bind(on_release=lambda *_: self.run_core_analysis())
        root.add_widget(an_btn)
        rk = SoftButton(text="محاسبه ریسک فارسی (۱٪)", bg=C_CARD2, size_hint_y=None, height=dp(40))
        rk.bind(on_release=lambda *_: self.calc_risk())
        root.add_widget(rk)
        wl = SoftButton(text="افزودن به واچ‌لیست", bg=C_CARD2, size_hint_y=None, height=dp(40))
        wl.bind(on_release=lambda *_: self.add_watch())
        root.add_widget(wl)
        ca = SoftButton(text="بستن همه پوزیشن‌ها", bg=C_RED, fg=(1,1,1,1), size_hint_y=None, height=dp(40))
        ca.bind(on_release=lambda *_: self.close_all())
        root.add_widget(ca)

        ar = BoxLayout(size_hint_y=None, height=dp(44), spacing=dp(8))
        self.auto_btn = SoftButton(text="Auto-Trade روشن", bg=C_BLUE, fg=(1, 1, 1, 1))
        self.auto_stop = SoftButton(text="توقف", bg=C_RED, fg=(1, 1, 1, 1), size_hint_x=0.35)
        self.auto_btn.bind(on_release=lambda *_: self.start_auto())
        self.auto_stop.bind(on_release=lambda *_: self.stop_auto())
        ar.add_widget(self.auto_btn)
        ar.add_widget(self.auto_stop)
        root.add_widget(ar)

        self.status = Sub("آماده برای معامله")
        self.status.height = dp(28)
        self.status.color = C_CYAN
        root.add_widget(self.status)
        root.add_widget(SectionLabel("پوزیشن‌های باز"))

        self.pos_box = GridLayout(cols=1, spacing=dp(8), size_hint_y=None)
        self.pos_box.bind(minimum_height=self.pos_box.setter("height"))
        sc = ScrollView()
        sc.add_widget(self.pos_box)
        root.add_widget(sc)
        self.add_widget(root)
        self._auto = False
        Clock.schedule_interval(lambda dt: self.tick(), 4)

    def set_side(self, s):
        self.side = s
        if s == "LONG":
            self.btn_long.set_bg(C_GREEN)
            self.btn_long.color = (0.02, 0.08, 0.05, 1)
            self.btn_short.set_bg(C_CARD2)
            self.btn_short.color = C_TEXT
        else:
            self.btn_short.set_bg(C_RED)
            self.btn_short.color = (1, 1, 1, 1)
            self.btn_long.set_bg(C_CARD2)
            self.btn_long.color = C_TEXT

    def fetch_price(self):
        sym = self.sym.text.strip() or "BTC"
        self.status.text = "دریافت قیمت چندمنبعی…"

        def work():
            try:
                t = mapi.get_ticker(sym)
                try:
                    fr = mapi.funding_rate(sym)
                except Exception:
                    fr = None
                def ui(*_):
                    px = t.get("price")
                    self.price_lbl.text = pxfmt(px)
                    ch = t.get("change_pct")
                    chs = f"{ch:+.2f}%" if ch is not None else "—"
                    hi, lo, vol = t.get("high"), t.get("low"), t.get("volume")
                    frs = (f" · fund {fr:.4%}" if isinstance(fr, (int, float)) else "")
                    self.meta.text = f"{t.get('source') or '—'} · 24h {chs} · H {pxfmt(hi)} L {pxfmt(lo)}{frs}"
                    self.meta.color = C_GREEN if (ch or 0) >= 0 else C_RED
                    if px and self.order_type.text == "بازار":
                        self.entry.text = str(px)
                    app = App.get_running_app()
                    app.current_symbol = sym
                    app.current_price = px
                    base = sym.upper().replace("-USDT", "").replace("USDT", "")
                    if px:
                        app.price_cache[base] = px
                        app.price_cache[base + "-USDT"] = px
                    self.status.text = "قیمت زنده ثبت شد در موتور و پرتفوی"
                    app.refresh_header()
                Clock.schedule_once(ui)
            except Exception as e:
                Clock.schedule_once(lambda *_: setattr(self.status, "text", f"خطا: {e}"))

        threading.Thread(target=work, daemon=True).start()

    def open_pos(self):
        try:
            sym = (self.sym.text.strip() or "BTC").upper().replace("USDT", "")
            pair = sym + "-USDT"
            entry = float(self.entry.text or 0)
            if entry <= 0:
                entry = float(App.get_running_app().current_price or 0)
            if entry <= 0:
                self.status.text = "ابتدا قیمت معتبر بگیرید"
                return
            margin = float(self.margin.text or 0)
            lev = float(self.lev.text or 5)
            tp1 = float(self.tp1.text) if self.tp1.text else None
            sl = float(self.sl.text) if self.sl.text else None
            trail = float(self.trail.text or 0)
            otype = self.order_type.text
            res = db.place_order(
                pair, self.side, otype, entry, lev, margin,
                tp1=tp1, sl=sl, trail_pct=trail, note="ui",
            )
            if res.get("order_type") in ("limit", "stop"):
                self.status.text = f"سفارش {res['order_type']} #{res['id']} ثبت شد"
            else:
                self.status.text = f"پوزیشن #{res.get('id')} باز شد"
            self.refresh_positions()
            App.get_running_app().refresh_wallet()
            App.get_running_app().refresh_header()
        except Exception as e:
            self.status.text = f"خطا: {e}"

    def refresh_positions(self):
        self.pos_box.clear_widgets()
        app = App.get_running_app()
        for p in db.list_open_positions():
            box = BoxLayout(size_hint_y=None, height=dp(56), spacing=dp(6), padding=[dp(10), dp(6)])
            with box.canvas.before:
                Color(*C_CARD2)
                box._bg = RoundedRectangle(radius=[dp(10)])
            box.bind(pos=lambda b, *a: setattr(b._bg, "pos", b.pos), size=lambda b, *a: setattr(b._bg, "size", b.size))
            base = p["symbol"].replace("-USDT", "")
            px = app.price_cache.get(base)
            extra = ""
            col = C_TEXT
            if px:
                u = db.position_pnl(p, px)
                extra = f"  {u['pnl']:+.2f}$"
                col = C_GREEN if u["pnl"] >= 0 else C_RED
            box.add_widget(Label(
                text=f"{p['symbol']} {p['side']} @ {pxfmt(p['entry'])}{extra}",
                color=col, font_size=dp(12),
            ))
            b25 = SoftButton(text="۲۵٪", bg=C_CARD, size_hint_x=0.14)
            b50 = SoftButton(text="۵۰٪", bg=C_CARD, size_hint_x=0.14)
            b100 = SoftButton(text="بستن", bg=C_RED, fg=(1, 1, 1, 1), size_hint_x=0.18)
            brev = SoftButton(text="معکوس", bg=C_BLUE, fg=(1,1,1,1), size_hint_x=0.18)
            b25.bind(on_release=lambda btn, i=p["id"], s=p["symbol"]: self.close_pos(i, s, 25))
            b50.bind(on_release=lambda btn, i=p["id"], s=p["symbol"]: self.close_pos(i, s, 50))
            b100.bind(on_release=lambda btn, i=p["id"], s=p["symbol"]: self.close_pos(i, s, 100))
            brev.bind(on_release=lambda btn, i=p["id"], s=p["symbol"]: self.reverse_one(i, s))
            for bx in (b25, b50, b100, brev):
                box.add_widget(bx)
            self.pos_box.add_widget(box)

    def close_pos(self, pid, sym, pct):
        def work():
            try:
                # FRESH price only — never silent stale
                price = mapi.get_live_price(sym)
                if not price:
                    raise ValueError("قیمت زنده در دسترس نیست — بستن لغو شد")
                r = db.close_position(pid, price, pct, "MANUAL")
                Clock.schedule_once(lambda *_: self._closed(r))
            except Exception as e:
                Clock.schedule_once(lambda *_: setattr(self.status, "text", f"خطا: {e}"))

        threading.Thread(target=work, daemon=True).start()

    def _closed(self, r):
        self.status.text = f"بسته شد · PnL {money(r['pnl'])}"
        self.refresh_positions()
        App.get_running_app().refresh_wallet()
        App.get_running_app().refresh_header()

    def tick(self):
        self.refresh_positions()

        def work():
            app = App.get_running_app()
            syms = set()
            for p in db.list_open_positions():
                syms.add(p["symbol"].replace("-USDT", ""))
            for o in db.list_open_orders():
                syms.add(o["symbol"].replace("-USDT", ""))
            if self._auto:
                for c in COINS[:12]:
                    syms.add(c)
            if not syms:
                return
            try:
                fresh = mapi.get_prices_batch(list(syms))
                if not fresh:
                    return  # do not run TP/SL on empty/stale
                app.price_cache.update(fresh)
            except Exception:
                return
            ev = []
            try:
                ev += db.process_pending_orders(app.price_cache)
            except Exception:
                pass
            try:
                ev += db.apply_tp_sl_trail(app.price_cache)
            except Exception:
                pass
            try:
                ev += db.process_alerts(app.price_cache)
            except Exception:
                pass
            if self._auto and len(db.list_open_positions()) < 10:
                for coin in COINS[:8]:
                    if not self._auto:
                        break
                    if any(p["symbol"].startswith(coin) for p in db.list_open_positions()):
                        continue
                    try:
                        res = core_an.full_symbol_analysis(coin, "1hour")
                        sig = core_an.signal_dict_for_trade(res)
                        min_c = 4
                        try:
                            min_c = int(float(load_prefs().get("min_conviction") or 4))
                        except Exception:
                            pass
                        if not sig or int(sig.get("conviction") or 0) < min_c:
                            continue
                        px = float(sig["entry"])
                        app.price_cache[coin] = px
                        db.open_position(
                            coin + "-USDT", sig["side"], px, 5, 5.0,
                            tp1=sig.get("tp1"), sl=sig.get("sl"),
                            source="auto", trail_pct=1.2,
                        )
                        ev.append("AUTO %s %s c%s" % (sig["side"], coin, sig.get("conviction")))
                    except Exception:
                        pass
            if ev:
                msg = " | ".join(ev[:5])
                Clock.schedule_once(lambda *_: setattr(self.status, "text", msg))
                Clock.schedule_once(lambda *_: self.refresh_positions())
                Clock.schedule_once(lambda *_: app.refresh_wallet())
                Clock.schedule_once(lambda *_: app.refresh_header())
            else:
                Clock.schedule_once(lambda *_: app.refresh_header())

        threading.Thread(target=work, daemon=True).start()


    def run_core_analysis(self):
        sym = self.sym.text.strip() or "BTC"
        self.status.text = "تحلیل چندتایم‌فریم + یادگیری…"
        def work():
            try:
                L = learn.learn_from_history()
                prefs = load_prefs()
                min_c = int(float(prefs.get("min_conviction") or 4))
                res = core_an.full_symbol_analysis_flex(sym, ["15min", "1hour", "4hour"], learning=L, min_conviction=min_c)
                # format from nested analysis
                text = core_an.format_analysis_fa(res)
                text += "\n" + learn.format_learning_fa(L)
                a = res.get("analysis") or {}
                sig = None
                if a.get("side") in ("LONG", "SHORT"):
                    sig = {
                        "side": a["side"], "entry": a.get("entry"), "sl": a.get("sl"),
                        "tp1": a.get("tp1"), "tp2": a.get("tp2"), "tp3": a.get("tp3"),
                        "conviction": a.get("conviction"),
                    }
                snap = res.get("snapshot") or {}
                def ui(*_):
                    px = snap.get("price")
                    if px:
                        self.price_lbl.text = pxfmt(px)
                        app = App.get_running_app()
                        app.current_price = px
                        app.price_cache[sym.upper().replace("-USDT","").replace("USDT","")] = px
                    if sig:
                        self.set_side(sig["side"])
                        if sig.get("entry"):
                            self.entry.text = str(round(float(sig["entry"]), 8))
                        if sig.get("sl"):
                            self.sl.text = str(round(float(sig["sl"]), 8))
                        if sig.get("tp1"):
                            self.tp1.text = str(round(float(sig["tp1"]), 8))
                        self.status.text = "MTF %s · قدرت %s/10 · align %.0f%% · فرم پر شد" % (
                            sig["side"], sig.get("conviction"), 100 * float(a.get("mtf_align") or 0))
                    else:
                        self.status.text = "خنثی / فیلتر قدرت — فرم تغییر نکرد"
                    App.get_running_app().last_core_text = text
                    App.get_running_app().last_learning = L
                Clock.schedule_once(ui)
            except Exception as e:
                Clock.schedule_once(lambda *_: setattr(self.status, "text", "خطا هسته: %s" % e))
        threading.Thread(target=work, daemon=True).start()


    def calc_risk(self):
        try:
            w = db.get_wallet()
            entry = float(self.entry.text or App.get_running_app().current_price or 0)
            sl = float(self.sl.text or 0)
            lev = float(self.lev.text or 5)
            if entry <= 0 or sl <= 0:
                self.status.text = "ورود و حد ضرر را برای محاسبه ریسک پر کن"
                return
            r = db.risk_size(float(w.get("balance") or 0), 1.0, entry, sl, lev)
            if r.get("error"):
                self.status.text = "فاصله حد ضرر نامعتبر"
                return
            self.margin.text = str(round(r["margin"], 4))
            self.status.text = "ریسک ۱٪ ≈ $%.2f | مارجین پیشنهادی $%.2f | qty %.6f" % (
                r["risk_usd"], r["margin"], r["qty"])
        except Exception as e:
            self.status.text = str(e)

    def add_watch(self):
        try:
            sym = self.sym.text.strip() or "BTC"
            db.watchlist_add(sym)
            self.status.text = "واچ‌لیست: %s اضافه شد" % sym.upper()
        except Exception as e:
            self.status.text = str(e)


    def close_all(self):
        self.status.text = "بستن همه…"
        def work():
            app = App.get_running_app()
            try:
                bases = [p["symbol"].replace("-USDT","") for p in db.list_open_positions()]
                if bases:
                    app.price_cache.update(mapi.get_prices_batch(bases))
                ev = db.close_all_positions(app.price_cache)
                msg = " | ".join(ev[:5]) if ev else "پوزیشنی نبود"
                Clock.schedule_once(lambda *_: setattr(self.status, "text", msg))
                Clock.schedule_once(lambda *_: self.refresh_positions())
                Clock.schedule_once(lambda *_: app.refresh_wallet())
                Clock.schedule_once(lambda *_: app.refresh_header())
            except Exception as e:
                Clock.schedule_once(lambda *_: setattr(self.status, "text", str(e)))
        threading.Thread(target=work, daemon=True).start()

    def reverse_one(self, pid, sym):
        def work():
            try:
                px = mapi.get_live_price(sym)
                if not px:
                    raise ValueError("قیمت زنده نیست")
                r = db.reverse_position(pid, px)
                Clock.schedule_once(lambda *_: setattr(self.status, "text", "معکوس شد #%s %s" % (r.get("id"), r.get("side"))))
                Clock.schedule_once(lambda *_: self.refresh_positions())
                Clock.schedule_once(lambda *_: App.get_running_app().refresh_wallet())
            except Exception as e:
                Clock.schedule_once(lambda *_: setattr(self.status, "text", str(e)))
        threading.Thread(target=work, daemon=True).start()

    def start_auto(self):
        self._auto = True
        self.status.text = "Auto-Trade پیوسته فعال است"
        self.tick()

    def stop_auto(self):
        self._auto = False
        self.status.text = "Auto-Trade متوقف شد"


class ChartScreen(Screen):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        root = BoxLayout(orientation="vertical", padding=dp(12), spacing=dp(10))
        root.add_widget(Title("چارت", 22, C_BLUE))
        row = BoxLayout(size_hint_y=None, height=dp(46), spacing=dp(8))
        self.sym = SoftInput(text="BTC")
        self.tf = Spinner(text="1hour", values=("15min", "1hour", "4hour", "1day"), background_color=C_CARD2, color=C_TEXT)
        btn = SoftButton(text="بارگذاری", bg=C_GOLD, fg=(0.05, 0.05, 0.05, 1), size_hint_x=0.35)
        btn.bind(on_release=lambda *_: self.load())
        row.add_widget(self.sym)
        row.add_widget(self.tf)
        row.add_widget(btn)
        self.chart = CandleChart()
        self.info = Sub("کندل زنده از بازار")
        root.add_widget(row)
        root.add_widget(self.chart)
        root.add_widget(self.info)
        self.add_widget(root)

    def load(self):
        sym = self.sym.text.strip() or "BTC"
        tf = self.tf.text
        self.info.text = "بارگذاری…"

        def work():
            try:
                c = mapi.fetch_candles(sym, tf)
                Clock.schedule_once(lambda *_: self.chart.set_candles(c))
                Clock.schedule_once(lambda *_: setattr(self.info, "text", f"{len(c)} کندل · {sym} · {tf}"))
            except Exception as e:
                Clock.schedule_once(lambda *_: setattr(self.info, "text", f"خطا: {e}"))

        threading.Thread(target=work, daemon=True).start()


class WalletScreen(Screen):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        root = BoxLayout(orientation="vertical", padding=dp(12), spacing=dp(8))
        root.add_widget(Title("پرتفوی و ولت", 22, C_BLUE))

        # hero metrics
        hero = CardBox(size_hint_y=None, height=dp(150))
        self.bal = Label(text="$100.00", color=C_GOLD, bold=True, font_size=dp(28), size_hint_y=None, height=dp(36))
        self.eq = Sub("اکوئیتی —")
        self.row_m = BoxLayout(size_hint_y=None, height=dp(48), spacing=dp(6))
        self.m_upnl = SoftButton(text="باز\n—", bg=C_CARD2, fg=C_TEXT, font_size=dp(11))
        self.m_rpnl = SoftButton(text="بسته\n—", bg=C_CARD2, fg=C_TEXT, font_size=dp(11))
        self.m_roi = SoftButton(text="ROI\n—", bg=C_CARD2, fg=C_TEXT, font_size=dp(11))
        self.m_dd = SoftButton(text="DD\n—", bg=C_CARD2, fg=C_TEXT, font_size=dp(11))
        for b in (self.m_upnl, self.m_rpnl, self.m_roi, self.m_dd):
            self.row_m.add_widget(b)
        hero.add_widget(self.bal)
        hero.add_widget(self.eq)
        hero.add_widget(self.row_m)
        root.add_widget(hero)

        self.stats = Sub("معاملات — · برد — · مارجین درگیر —")
        root.add_widget(self.stats)

        # cash ops
        row = BoxLayout(size_hint_y=None, height=dp(46), spacing=dp(8))
        self.amt = SoftInput(text="20", input_filter="float", hint_text="مبلغ واریز/برداشت")
        bd = SoftButton(text="واریز", bg=C_GREEN, fg=(0.02, 0.08, 0.05, 1))
        bw = SoftButton(text="برداشت", bg=C_RED, fg=(1, 1, 1, 1))
        bd.bind(on_release=lambda *_: self.cash(True))
        bw.bind(on_release=lambda *_: self.cash(False))
        row.add_widget(self.amt)
        row.add_widget(bd)
        row.add_widget(bw)
        root.add_widget(row)

        # reports
        r2 = BoxLayout(size_hint_y=None, height=dp(44), spacing=dp(8))
        bcsv = SoftButton(text="گزارش CSV", bg=C_BLUE, fg=(1, 1, 1, 1))
        bjson = SoftButton(text="گزارش JSON", bg=C_CARD2)
        bref = SoftButton(text="رفرش قیمت", bg=C_GOLD, fg=(0.05, 0.05, 0.05, 1), size_hint_x=0.35)
        bcsv.bind(on_release=lambda *_: self.export("csv"))
        bjson.bind(on_release=lambda *_: self.export("json"))
        bref.bind(on_release=lambda *_: self.refresh_prices())
        r2.add_widget(bcsv)
        r2.add_widget(bjson)
        r2.add_widget(bref)
        root.add_widget(r2)

        self.msg = Sub("")
        root.add_widget(self.msg)

        # tabs-like: positions / trades / ledger
        root.add_widget(SectionLabel("پوزیشن‌های باز"))
        self.pos_box = GridLayout(cols=1, spacing=dp(4), size_hint_y=None)
        self.pos_box.bind(minimum_height=self.pos_box.setter("height"))
        sc1 = ScrollView(size_hint_y=0.28)
        sc1.add_widget(self.pos_box)
        root.add_widget(sc1)

        root.add_widget(Title("تاریخچه معاملات و واریز", 14, C_MUTED))
        self.hist_box = GridLayout(cols=1, spacing=dp(3), size_hint_y=None)
        self.hist_box.bind(minimum_height=self.hist_box.setter("height"))
        sc2 = ScrollView()
        sc2.add_widget(self.hist_box)
        root.add_widget(sc2)
        self.add_widget(root)

    def on_enter(self, *a):
        self.refresh()

    def refresh_prices(self):
        self.msg.text = "به‌روزرسانی قیمت پرتفوی…"
        def work():
            app = App.get_running_app()
            bases = []
            for p in db.list_open_positions():
                bases.append(p["symbol"].replace("-USDT", ""))
            try:
                if bases:
                    fresh = mapi.get_prices_batch(bases)
                    app.price_cache.update(fresh)
            except Exception as e:
                Clock.schedule_once(lambda *_: setattr(self.msg, "text", str(e)))
                return
            Clock.schedule_once(lambda *_: self.refresh())
            Clock.schedule_once(lambda *_: setattr(self.msg, "text", "قیمت پرتفوی به‌روز شد"))
            Clock.schedule_once(lambda *_: app.refresh_header())
        threading.Thread(target=work, daemon=True).start()

    def refresh(self):
        app = App.get_running_app()
        st = db.portfolio_stats(app.price_cache)
        self.bal.text = "$" + money(st["balance"])
        self.eq.text = "اکوئیتی $%s · آزاد $%s · قفل $%s" % (money(st["equity"]), money(st.get("free_balance", st["balance"])), money(st.get("locked_margin") or 0))
        self.m_upnl.text = "باز\n%s" % money(st["unrealized"])
        self.m_upnl.color = C_GREEN if st["unrealized"] >= 0 else C_RED
        self.m_rpnl.text = "بسته\n%s" % money(st["realized_pnl"])
        self.m_rpnl.color = C_GREEN if st["realized_pnl"] >= 0 else C_RED
        self.m_roi.text = "ROI\n%.1f%%" % (st["roi_pct"] or 0)
        self.m_dd.text = "DD\n%.1f%%" % (st["drawdown_pct"] or 0)
        self.stats.text = "معاملات %d · برد %.0f%% · باز %d · مارجین درگیر $%s · PF %s" % (
            st["trade_count"], st["winrate"], st["open_count"], money(st["margin_used"]),
            ("%.2f" % st["profit_factor"]) if st["profit_factor"] else "—",
        )
        self.pos_box.clear_widgets()
        for p in st["positions"]:
            pnl = p.get("pnl")
            col = C_TEXT if pnl is None else (C_GREEN if pnl >= 0 else C_RED)
            line = "%s %s @ %s → %s | PnL %s (ROE %s)" % (
                p.get("symbol"), p.get("side"), pxfmt(p.get("entry")),
                pxfmt(p.get("live_price")) if p.get("live_price") else "—",
                money(pnl) if pnl is not None else "—",
                ("%.1f%%" % p["roe"]) if p.get("roe") is not None else "—",
            )
            self.pos_box.add_widget(Label(text=line, color=col, size_hint_y=None, height=dp(26), font_size=dp(11)))
        if not st["positions"]:
            self.pos_box.add_widget(Label(text="پوزیشن بازی نیست", color=C_MUTED, size_hint_y=None, height=dp(24)))
        self.hist_box.clear_widgets()
        for t in db.list_trades(30):
            col = C_GREEN if (t.get("pnl") or 0) >= 0 else C_RED
            self.hist_box.add_widget(Label(
                text="%s %s PnL %s fee %s · %s" % (
                    t.get("symbol"), t.get("side"), money(t.get("pnl")), money(t.get("fee")), t.get("reason")),
                color=col, size_hint_y=None, height=dp(24), font_size=dp(11),
            ))
        for L in db.list_ledger(20):
            self.hist_box.add_widget(Label(
                text="ولجر %s %s → bal %s" % (L.get("type"), money(L.get("amount")), money(L.get("balance_after"))),
                color=C_MUTED, size_hint_y=None, height=dp(22), font_size=dp(10),
            ))

    def cash(self, dep):
        try:
            a = abs(float(self.amt.text or 0))
            db.deposit(a if dep else -a, "wallet_ui")
            self.refresh()
            App.get_running_app().refresh_header()
            self.msg.text = "ثبت شد در دفتر ولت"
        except Exception as e:
            self.msg.text = str(e)

    def export(self, kind="csv"):
        self.msg.text = "ساخت گزارش…"
        def work():
            app = App.get_running_app()
            # refresh marks first
            try:
                bases = [p["symbol"].replace("-USDT", "") for p in db.list_open_positions()]
                if bases:
                    app.price_cache.update(mapi.get_prices_batch(bases))
            except Exception:
                pass
            try:
                base = os.environ.get("APEX_DATA") or os.path.expanduser("~/.apex_native")
                os.makedirs(base, exist_ok=True)
                if kind == "json":
                    text = db.export_report_json(app.price_cache)
                    path = os.path.join(base, "apex_report.json")
                else:
                    text = db.export_report_csv(app.price_cache)
                    path = os.path.join(base, "apex_report.csv")
                with open(path, "w", encoding="utf-8") as f:
                    f.write(text)
                Clock.schedule_once(lambda *_: setattr(self.msg, "text", "ذخیره شد: " + path))
                Clock.schedule_once(lambda *_: self.refresh())
            except Exception as e:
                Clock.schedule_once(lambda *_: setattr(self.msg, "text", str(e)))
        threading.Thread(target=work, daemon=True).start()



class AIScreen(Screen):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        root = BoxLayout(orientation="vertical", padding=dp(12), spacing=dp(10))
        root.add_widget(Title("هوش مصنوعی", 22, C_BLUE))
        self.model = Spinner(text=MODELS[0], values=tuple(MODELS), size_hint_y=None, height=dp(44), background_color=C_CARD2, color=C_TEXT)
        self.key = SoftInput(hint_text="کلید Coarena", password=True)
        self.sym = SoftInput(text="BTC", hint_text="نماد")
        self.prompt = SoftInput(hint_text="پیام چت…", multiline=True, height=dp(72))
        row = BoxLayout(size_hint_y=None, height=dp(48), spacing=dp(8))
        b1 = SoftButton(text="تحلیل ترید", bg=C_GOLD, fg=(0.05, 0.05, 0.05, 1))
        b2 = SoftButton(text="چت", bg=C_BLUE, fg=(1, 1, 1, 1))
        b1.bind(on_release=lambda *_: self.analyze())
        b2.bind(on_release=lambda *_: self.chat())
        row.add_widget(b1)
        row.add_widget(b2)
        self.out = TextInput(
            text="", multiline=True, readonly=True,
            background_normal="", background_active="",
            background_color=C_CARD, foreground_color=C_TEXT, padding=dp(12),
        )
        root.add_widget(self.model)
        root.add_widget(self.key)
        root.add_widget(self.sym)
        root.add_widget(self.prompt)
        root.add_widget(row)
        root.add_widget(self.out)
        self.add_widget(root)
        k0 = db.get_secret("coarena_key")
        if k0:
            self.key.text = k0

    def _key(self):
        k = self.key.text.strip()
        if not k:
            self.out.text = "کلید Coarena لازم است"
            return None
        db.set_secret("coarena_key", k)
        db.set_setting("coarena_model", self.model.text)
        return k

    def analyze(self):
        key = self._key()
        if not key:
            return
        sym = self.sym.text.strip() or "BTC"
        self.out.text = "هسته داده + AI…"

        def work():
            try:
                L = learn.learn_from_history()
                prefs = load_prefs()
                min_c = int(float(prefs.get("min_conviction") or 4))
                res = core_an.full_symbol_analysis_flex(sym, ["15min", "1hour", "4hour"], learning=L, min_conviction=min_c)
                core_txt = core_an.format_analysis_fa(res) + "\n" + learn.format_learning_fa(L)
                learn_ctx = learn.ai_context_from_learning(L)
                a = res.get("analysis") or {}
                s = res.get("snapshot") or {}
                user = (
                    "You are APEX. Use LIVE multi-TF analysis + trader learning. Adapt to this user.\n" + learn_ctx + "\n"
                    + core_txt + "\n"
                    "Enrich in Persian: final side, entry, TP1/2/3, SL, leverage, conviction 1-10, "
                    "and one invalidation rule. Prefer core side unless clearly wrong."
                )
                text = cai.apex_analyze(
                    key, user, "APEX senior desk analyst. Persian. Use multi-TF structure, funding, and trader learning. Give invalidation and risk note.",
                    model=self.model.text, reasoning_effort="high",
                )
                full = core_txt + "\n\n--- AI ---\n" + text
                db.add_chat("assistant", full, self.model.text)
                # push levels to trade screen if signal
                sig = core_an.signal_dict_for_trade(res)
                def ui(*_):
                    self.out.text = full
                    if sig:
                        try:
                            tr = App.get_running_app().sm.get_screen("trade")
                            tr.sym.text = sym
                            tr.set_side(sig["side"])
                            if sig.get("entry"):
                                tr.entry.text = str(round(float(sig["entry"]), 8))
                            if sig.get("sl"):
                                tr.sl.text = str(round(float(sig["sl"]), 8))
                            if sig.get("tp1"):
                                tr.tp1.text = str(round(float(sig["tp1"]), 8))
                            if s.get("price"):
                                tr.price_lbl.text = pxfmt(s.get("price"))
                        except Exception:
                            pass
                Clock.schedule_once(ui)
            except Exception as e:
                # fallback core only
                try:
                    res = core_an.full_symbol_analysis(sym, "1hour")
                    text = core_an.format_analysis_fa(res) + "\n\nAI error: " + str(e)
                except Exception as e2:
                    text = "خطا: %s | %s" % (e, e2)
                Clock.schedule_once(lambda *_: setattr(self.out, "text", text))

        threading.Thread(target=work, daemon=True).start()

    def chat(self):
        key = self._key()
        if not key:
            return
        msg = self.prompt.text.strip()
        if not msg:
            self.out.text = "پیام خالی"
            return
        self.out.text = "…"
        db.add_chat("user", msg, self.model.text)

        def work():
            try:
                text = cai.chat(key, [{"role": "user", "content": msg}], model=self.model.text, max_tokens=2048)
                db.add_chat("assistant", text, self.model.text)
                Clock.schedule_once(lambda *_: setattr(self.out, "text", text))
            except Exception as e:
                Clock.schedule_once(lambda *_: setattr(self.out, "text", f"خطا: {e}"))

        threading.Thread(target=work, daemon=True).start()


class MoreScreen(Screen):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        root = BoxLayout(orientation="vertical", padding=dp(12), spacing=dp(10))
        root.add_widget(Title("بیشتر · شخصی‌سازی", 22, C_BLUE))
        pref_row = GridLayout(cols=2, spacing=dp(6), size_hint_y=None, height=dp(150))
        self.p_lev = SoftInput(hint_text="اهرم پیش‌فرض", input_filter="float")
        self.p_margin = SoftInput(hint_text="مارجین پیش‌فرض", input_filter="float")
        self.p_conv = SoftInput(hint_text="حداقل قدرت سیگنال", input_filter="float")
        self.p_tf = SoftInput(hint_text="TF ترجیحی", multiline=False)
        self.p_daily = SoftInput(hint_text="حد ضرر روزانه $ (0=خاموش)", input_filter="float")
        for w in (self.p_lev, self.p_margin, self.p_conv, self.p_tf, self.p_daily):
            pref_row.add_widget(w)
        root.add_widget(pref_row)
        sp = SoftButton(text="ذخیره شخصی‌سازی", bg=C_BLUE, fg=(1,1,1,1), size_hint_y=None, height=dp(42))
        sp.bind(on_release=lambda *_: self.save_personal())
        root.add_widget(sp)
        bl = SoftButton(text="گزارش یادگیری معاملات", bg=C_GOLD, fg=(0.05,0.05,0.05,1), size_hint_y=None, height=dp(42))
        bl.bind(on_release=lambda *_: self.show_learning())
        root.add_widget(bl)
        self.learn_lbl = Sub("")
        self.learn_lbl.height = dp(90)
        root.add_widget(self.learn_lbl)
        self.title_in = SoftInput(hint_text="عنوان یادداشت")
        self.body_in = SoftInput(hint_text="متن", multiline=True, height=dp(90))
        save = SoftButton(text="ذخیره یادداشت", bg=C_GREEN, fg=(0.02, 0.08, 0.05, 1), size_hint_y=None, height=dp(46))
        save.bind(on_release=lambda *_: self.save())
        root.add_widget(self.title_in)
        root.add_widget(self.body_in)
        root.add_widget(save)
        self.box = GridLayout(cols=1, spacing=dp(4), size_hint_y=None)
        self.box.bind(minimum_height=self.box.setter("height"))
        sc = ScrollView(size_hint_y=0.45)
        sc.add_widget(self.box)
        root.add_widget(sc)
        hb = SoftButton(text="سلامت APIها", bg=C_CARD2, size_hint_y=None, height=dp(44))
        hb.bind(on_release=lambda *_: self.health())
        self.health_lbl = Sub("")
        self.health_lbl.height = dp(90)
        root.add_widget(hb)
        root.add_widget(self.health_lbl)
        self.add_widget(root)

    def save_personal(self):
        try:
            save_prefs({
                "default_leverage": self.p_lev.text or "5",
                "default_margin": self.p_margin.text or "10",
                "min_conviction": self.p_conv.text or "4",
                "prefer_tf": self.p_tf.text or "1hour",
            })
            db.set_setting("pref_daily_loss", self.p_daily.text or "0")
            self.learn_lbl.text = "شخصی‌سازی ذخیره شد — در معامله بعدی اعمال می‌شود"
        except Exception as e:
            self.learn_lbl.text = str(e)

    def show_learning(self):
        def work():
            L = learn.learn_from_history()
            text = learn.format_learning_fa(L)
            Clock.schedule_once(lambda *_: setattr(self.learn_lbl, "text", text[:500]))
            App.get_running_app().last_learning = L
        threading.Thread(target=work, daemon=True).start()

    def on_enter(self, *a):
        self.reload()
        pr = load_prefs()
        try:
            self.p_lev.text = str(pr.get("default_leverage") or "5")
            self.p_margin.text = str(pr.get("default_margin") or "10")
            self.p_conv.text = str(pr.get("min_conviction") or "4")
            self.p_tf.text = str(pr.get("prefer_tf") or "1hour")
        except Exception:
            pass

    def save(self):
        db.add_note(self.title_in.text or "یادداشت", self.body_in.text or "", App.get_running_app().current_symbol or "")
        self.title_in.text = ""
        self.body_in.text = ""
        self.reload()

    def reload(self):
        self.box.clear_widgets()
        for n in db.list_notes(30):
            self.box.add_widget(Label(
                text=f"{n.get('title')}: {(n.get('body') or '')[:70]}",
                color=C_TEXT, size_hint_y=None, height=dp(32), font_size=dp(12),
            ))

    def health(self):
        def work():
            try:
                rows = mapi.health_check()
                txt = "\n".join(f"{'✓' if r['ok'] else '✗'} {r['name']} {r['ms']}ms" for r in rows)
                Clock.schedule_once(lambda *_: setattr(self.health_lbl, "text", txt))
            except Exception as e:
                Clock.schedule_once(lambda *_: setattr(self.health_lbl, "text", str(e)))

        threading.Thread(target=work, daemon=True).start()


class Nav(BoxLayout):
    def __init__(self, sm, **kwargs):
        super().__init__(size_hint_y=None, height=dp(68), padding=[dp(8), dp(8)], spacing=dp(6), **kwargs)
        with self.canvas.before:
            Color(0.02, 0.02, 0.03, 1)
            self._r = Rectangle()
            Color(*C_LINE)
            self._ln = Line(width=1)
        self.bind(pos=self._s, size=self._s)
        self.sm = sm
        self.btns = {}
        for name, title in (("trade", "معامله"), ("chart", "چارت"), ("wallet", "دارایی"), ("ai", "AI"), ("more", "بیشتر")):
            b = SoftButton(text=title, bg=C_CARD, fg=C_MUTED, font_size=dp(12), radius=12, height=dp(52))
            b.bind(on_release=lambda btn, n=name: self.go(n))
            self.btns[name] = b
            self.add_widget(b)
        self.go("trade")

    def _s(self, *a):
        self._r.pos = self.pos
        self._r.size = self.size
        self._ln.points = [self.x, self.top, self.right, self.top]

    def go(self, name):
        self.sm.current = name
        for n, b in self.btns.items():
            if n == name:
                b.color = (0, 0, 0, 1)
                b.set_bg(C_BLUE)
            else:
                b.color = C_MUTED
                b.set_bg(C_CARD)


class ApexApp(App):
    current_symbol = "BTC"
    current_price = None
    price_cache = {}

    def build(self):
        db.init_db()
        root = BoxLayout(orientation="vertical")
        self.header = HeaderBar()
        sm = ScreenManager(transition=NoTransition())
        sm.add_widget(TradeScreen(name="trade"))
        sm.add_widget(ChartScreen(name="chart"))
        sm.add_widget(WalletScreen(name="wallet"))
        sm.add_widget(AIScreen(name="ai"))
        sm.add_widget(MoreScreen(name="more"))
        self.sm = sm
        root.add_widget(self.header)
        root.add_widget(sm)
        root.add_widget(Nav(sm))
        Clock.schedule_once(lambda *_: self.refresh_header(), 0.5)
        return root

    def refresh_wallet(self):
        try:
            self.sm.get_screen("wallet").refresh()
        except Exception:
            pass

    def refresh_header(self):
        try:
            e = db.equity_with_marks(self.price_cache)
            self.header.set_equity(e["equity"], e["unrealized"])
        except Exception:
            pass


if __name__ == "__main__":
    ApexApp().run()
