# APEX Exchange Native — آماده ساخت APK با GitHub

اپ معاملاتی دمو با **پایتون + Kivy** (بدون WebView).

## محتویات
- `main.py` — رابط و صفحات
- `apex/storage.py` — حساب دمو، مارجین آزاد/قفل، سفارش، TP مرحله‌ای، تریل
- `apex/market_apis.py` — قیمت چندصرافی
- `apex/analysis.py` — تحلیل چندتایم‌فریم
- `apex/learning.py` — یادگیری از معاملات
- `apex/coarena_ai.py` — هوش مصنوعی Coarena
- `buildozer.spec` — تنظیمات بیلد اندروید
- `.github/workflows/build-apk.yml` — بیلد خودکار GitHub Actions

## ساخت APK با GitHub (مهم)

1. در GitHub یک مخزن **خالی** بساز (مثلاً `APEX-Native`).
2. فایل ZIP را روی گوشی/کامپیوتر **Extract** کن.
3. **همه فایل‌های داخل پوشه** را در **ریشهٔ مخزن** آپلود کن  
   (باید `main.py` و `buildozer.spec` در root دیده شوند — نه داخل یک زیرپوشه).
4. برو: **Actions** → **Build APEX Native APK** → **Run workflow**.
5. بار اول اغلب **۴۵ تا ۹۰ دقیقه** طول می‌کشد.
6. پس از موفقیت، از **Artifacts** فایل `APEX-Exchange-Native-APK` را دانلود و نصب کن.

### اگر بیلد خطا داد
- لینک همان Run را باز کن و خطای قرمز را بخوان.
- معمولاً با Run دوباره (به‌خاطر cache) بهتر می‌شود.

## اجرا روی کامپیوتر (اختیاری)
```bash
pip install kivy
python main.py
```

## صفحات اپ
| صفحه | کار |
|------|-----|
| معامله | قیمت، سفارش بازار/حد/توقف، Auto-Trade، تحلیل هسته، ریسک |
| چارت | شمعی |
| دارایی | ولت آزاد/قفل، گزارش CSV/JSON، پرتفوی |
| AI | Coarena + مدل‌ها |
| بیشتر | شخصی‌سازی، یادگیری معاملات، یادداشت |

نسخه بسته: 2.1.0-ready
