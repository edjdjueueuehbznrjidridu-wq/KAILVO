[app]
title = APEX Exchange
package.name = apexexchange
package.domain = ai.apex.exchange
source.dir = .
source.include_exts = py,png,jpg,kv,atlas,json,txt,md
source.exclude_dirs = tests, bin, .git, __pycache__, .buildozer
version = 2.1.0
requirements = python3,kivy==2.3.0,certifi,openssl,sqlite3,hostpython3
orientation = portrait
fullscreen = 0
android.permissions = INTERNET,ACCESS_NETWORK_STATE
android.api = 33
android.minapi = 24
android.ndk = 25b
android.sdk = 33
android.accept_sdk_license = True
android.archs = arm64-v8a
android.allow_backup = True
android.logcat_filters = *:S python:D
p4a.branch = master
android.release_artifact = apk
android.debug_artifact = apk

[buildozer]
log_level = 2
warn_on_root = 0
bin_dir = ./bin
