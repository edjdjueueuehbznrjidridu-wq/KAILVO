# -*- coding: utf-8 -*-
"""Coarena Model API client — OpenAI-compatible, pure Python."""
from __future__ import annotations
import json
import time
import urllib.error
import urllib.request
from typing import Any, Dict, List, Optional

BASE_URL = "https://coarena.ai/api/v1"
DEFAULT_MODEL = "claude-sonnet-5-5"
UA = "APEX-Pro/14 (Android; Coarena)"

# Recommended models by role (ids from Coarena catalog)
MODELS = {
    "balanced": "claude-sonnet-5-5",
    "flagship": "claude-opus-5-5",
    "fast": "claude-haiku-5-5",
    "gemini": "gemini-4-carbon",
    "gemini_fast": "gemini-3-8-flash",
    "grok": "grok-4-7",
    "deepseek": "deepseek-v4-1-flash-1017",
    "kimi": "kimi-k3-1-pro",
    "qwen": "qwen3-8-2-4t-a95b",
}

class CoarenaError(Exception):
    def __init__(self, message: str, code: str = "", status: int = 0):
        super().__init__(message)
        self.code = code
        self.status = status


def _request(method: str, path: str, api_key: str, body: Optional[dict] = None, timeout: int = 90) -> dict:
    if not api_key or len(api_key) < 8:
        raise CoarenaError("کلید Coarena تنظیم نشده — از تنظیمات وارد کنید", "no_key", 401)
    url = BASE_URL.rstrip("/") + path
    data = None
    headers = {
        "Authorization": "Bearer " + api_key.strip(),
        "User-Agent": UA,
        "Accept": "application/json",
    }
    if body is not None:
        data = json.dumps(body, ensure_ascii=False).encode("utf-8")
        headers["Content-Type"] = "application/json"
    req = urllib.request.Request(url, data=data, headers=headers, method=method)
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            raw = r.read().decode("utf-8")
            if not raw:
                return {}
            return json.loads(raw)
    except urllib.error.HTTPError as e:
        err_body = ""
        try:
            err_body = e.read().decode("utf-8")[:500]
        except Exception:
            pass
        code = ""
        msg = err_body or str(e)
        try:
            j = json.loads(err_body)
            err = j.get("error") or j
            msg = err.get("message") or msg
            code = err.get("code") or err.get("type") or ""
        except Exception:
            pass
        if e.code == 401:
            raise CoarenaError("کلید API نامعتبر است", "401", 401)
        if e.code == 429:
            raise CoarenaError("محدودیت نرخ — کمی صبر کنید", "429", 429)
        if code == "model_off":
            raise CoarenaError("این مدل فعلاً خاموش است — مدل دیگری انتخاب کنید", "model_off", e.code)
        raise CoarenaError(msg[:200], code or str(e.code), e.code)
    except urllib.error.URLError as e:
        raise CoarenaError("خطای شبکه: " + str(e.reason)[:120], "network", 0)


def list_models(api_key: str) -> List[dict]:
    j = _request("GET", "/models", api_key, timeout=30)
    return list(j.get("data") or [])


def chat(
    api_key: str,
    messages: List[Dict[str, str]],
    model: str = DEFAULT_MODEL,
    max_tokens: int = 4096,
    temperature: float = 0.55,
    system: Optional[str] = None,
    reasoning_effort: Optional[str] = None,
    retries: int = 3,
) -> str:
    """Chat completion; returns assistant text. Retries on 429/network."""
    msgs = list(messages)
    if system:
        msgs = [{"role": "system", "content": system}] + msgs
    body: Dict[str, Any] = {
        "model": model or DEFAULT_MODEL,
        "messages": msgs,
        "max_tokens": min(int(max_tokens or 4096), 16384),
        "temperature": float(temperature),
        "stream": False,
    }
    if reasoning_effort:
        body["reasoning_effort"] = reasoning_effort

    last_err: Optional[Exception] = None
    for attempt in range(max(1, retries)):
        try:
            j = _request("POST", "/chat/completions", api_key, body, timeout=120)
            choices = j.get("choices") or []
            if not choices:
                raise CoarenaError("پاسخ خالی از مدل", "empty")
            msg = choices[0].get("message") or {}
            text = (msg.get("content") or "").strip()
            if not text:
                raise CoarenaError("متن پاسخ خالی است", "empty")
            return text
        except CoarenaError as e:
            last_err = e
            if e.code in ("429", "network") and attempt < retries - 1:
                time.sleep(1.2 * (attempt + 1))
                continue
            if e.code == "model_off" and model != DEFAULT_MODEL:
                # fallback once to sonnet
                model = DEFAULT_MODEL
                body["model"] = model
                continue
            raise
        except Exception as e:
            last_err = e
            if attempt < retries - 1:
                time.sleep(1.0 * (attempt + 1))
                continue
            raise CoarenaError(str(e)[:160], "unknown")
    raise CoarenaError(str(last_err or "خطای ناشناخته"), "failed")


def apex_analyze(
    api_key: str,
    user_prompt: str,
    system_prompt: str,
    model: str = DEFAULT_MODEL,
    reasoning_effort: str = "high",
) -> str:
    """APEX trading analysis call with retries."""
    return chat(
        api_key=api_key,
        messages=[{"role": "user", "content": user_prompt}],
        model=model,
        max_tokens=8192,
        temperature=0.5,
        system=system_prompt,
        reasoning_effort=reasoning_effort,
        retries=3,
    )
