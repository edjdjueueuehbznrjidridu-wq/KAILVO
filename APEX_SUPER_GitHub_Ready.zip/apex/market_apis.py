# -*- coding: utf-8 -*-
"""APEX market engine — multi-exchange, cached, resilient."""
from __future__ import annotations
import json, time, threading, urllib.request
from concurrent.futures import ThreadPoolExecutor, as_completed
from typing import Any, Dict, List, Optional, Tuple

UA = "APEX-Native/2 (Android)"
_lock = threading.RLock()
_cache: Dict[str, Tuple[float, Any]] = {}
TTL_PX = 1.5
TTL_SLOW = 12.0

def _get(url: str, timeout: int = 8) -> bytes:
    req = urllib.request.Request(url, headers={"User-Agent": UA, "Accept": "application/json"})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return r.read()

def _json(url: str, timeout: int = 8) -> Any:
    return json.loads(_get(url, timeout).decode("utf-8"))

def _cached(key: str, ttl: float, fn, negative_ttl: float = 0.8):
    """Cache successes longer; API failures only briefly so errors are not treated as real data."""
    now = time.time()
    with _lock:
        hit = _cache.get(key)
        if hit and now - hit[0] < hit[2]:
            return hit[1]
    try:
        val = fn()
    except Exception:
        with _lock:
            _cache[key] = (now, None, negative_ttl)
        raise
    # Treat empty ticker / null price as short negative cache
    bad = False
    if val is None:
        bad = True
    elif isinstance(val, dict) and key.startswith("tk:") and not val.get("price"):
        bad = True
    elif isinstance(val, list) and key.startswith("cd:") and len(val) == 0:
        bad = True
    ttl_use = negative_ttl if bad else ttl
    with _lock:
        _cache[key] = (now, val, ttl_use)
    return val

def normalize_symbol(symbol: str) -> Tuple[str, str, str]:
    s = (symbol or "BTC").upper().replace("_", "-").strip()
    if s.endswith("-USDT"):
        base = s[:-5]
    elif s.endswith("USDT"):
        base = s[:-4]
    else:
        base = "".join(c for c in s if c.isalnum())
    base = base or "BTC"
    return base, f"{base}-USDT", f"{base}USDT"

def _binance_price(base: str) -> Optional[float]:
    try:
        j = _json(f"https://api.binance.com/api/v3/ticker/price?symbol={base}USDT", 6)
        p = float(j.get("price") or 0)
        return p if p > 0 else None
    except Exception:
        return None

def _binance_24h(base: str) -> Optional[Dict[str, float]]:
    try:
        j = _json(f"https://api.binance.com/api/v3/ticker/24hr?symbol={base}USDT", 8)
        return {
            "price": float(j.get("lastPrice") or 0),
            "change_pct": float(j.get("priceChangePercent") or 0),
            "high": float(j.get("highPrice") or 0),
            "low": float(j.get("lowPrice") or 0),
            "volume": float(j.get("quoteVolume") or 0),
            "bid": float(j.get("bidPrice") or 0),
            "ask": float(j.get("askPrice") or 0),
        }
    except Exception:
        return None

def _kucoin_price(base: str) -> Optional[float]:
    try:
        j = _json(f"https://api.kucoin.com/api/v1/market/orderbook/level1?symbol={base}-USDT", 6)
        p = (j.get("data") or {}).get("price")
        return float(p) if p else None
    except Exception:
        return None

def _kucoin_stats(base: str) -> Optional[Dict[str, Any]]:
    try:
        j = _json(f"https://api.kucoin.com/api/v1/market/stats?symbol={base}-USDT", 8)
        d = j.get("data") or {}
        last = float(d.get("last") or 0)
        if last <= 0:
            return None
        return {
            "price": last,
            "change_pct": float(d.get("changeRate") or 0) * 100,
            "high": float(d.get("high") or 0),
            "low": float(d.get("low") or 0),
            "volume": float(d.get("volValue") or 0),
        }
    except Exception:
        return None

def _bybit_price(base: str) -> Optional[float]:
    try:
        j = _json(f"https://api.bybit.com/v5/market/tickers?category=spot&symbol={base}USDT", 6)
        lst = (j.get("result") or {}).get("list") or []
        if not lst:
            return None
        p = float(lst[0].get("lastPrice") or 0)
        return p if p > 0 else None
    except Exception:
        return None

def _okx_price(base: str) -> Optional[float]:
    try:
        j = _json(f"https://www.okx.com/api/v5/market/ticker?instId={base}-USDT", 6)
        data = (j.get("data") or [{}])[0]
        p = float(data.get("last") or 0)
        return p if p > 0 else None
    except Exception:
        return None

def _gate_price(base: str) -> Optional[float]:
    try:
        j = _json(f"https://api.gateio.ws/api/v4/spot/tickers?currency_pair={base}_USDT", 6)
        if isinstance(j, list) and j:
            p = float(j[0].get("last") or 0)
            return p if p > 0 else None
    except Exception:
        return None
    return None


def _mexc_price(base: str):
    try:
        j = _json(f"https://api.mexc.com/api/v3/ticker/price?symbol={base}USDT", 6)
        p = float(j.get("price") or 0)
        return p if p > 0 else None
    except Exception:
        return None

def _htx_price(base: str):
    try:
        j = _json(f"https://api.huobi.pro/market/detail/merged?symbol={base.lower()}usdt", 6)
        tick = j.get("tick") or {}
        p = float(tick.get("close") or 0)
        return p if p > 0 else None
    except Exception:
        return None

def _bitget_price(base: str):
    try:
        j = _json(f"https://api.bitget.com/api/v2/spot/market/tickers?symbol={base}USDT", 6)
        data = j.get("data") or []
        if not data:
            return None
        p = float(data[0].get("lastPr") or data[0].get("last") or 0)
        return p if p > 0 else None
    except Exception:
        return None

def _kraken_price(base: str):
    # Kraken uses XBT for BTC
    pair = "XBTUSDT" if base == "BTC" else f"{base}USDT"
    try:
        j = _json(f"https://api.kraken.com/0/public/Ticker?pair={pair}", 6)
        result = j.get("result") or {}
        if not result:
            return None
        key = next(iter(result.keys()))
        p = float(result[key]["c"][0])
        return p if p > 0 else None
    except Exception:
        return None

def _coinbase_price(base: str):
    try:
        j = _json(f"https://api.exchange.coinbase.com/products/{base}-USDT/ticker", 6)
        p = float(j.get("price") or 0)
        return p if p > 0 else None
    except Exception:
        try:
            j = _json(f"https://api.coinbase.com/v2/prices/{base}-USD/spot", 6)
            p = float((j.get("data") or {}).get("amount") or 0)
            return p if p > 0 else None
        except Exception:
            return None

def get_live_price(symbol: str) -> Optional[float]:
    base, _, _ = normalize_symbol(symbol)
    def _do():
        for fn in (_binance_price, _kucoin_price, _bybit_price, _okx_price, _gate_price, _mexc_price, _bitget_price, _htx_price, _kraken_price, _coinbase_price):
            p = fn(base)
            if p and p > 0:
                return p
        return None
    return _cached(f"px:{base}", TTL_PX, _do)

def get_ticker(symbol: str) -> Dict[str, Any]:
    base, kc, bn = normalize_symbol(symbol)
    def _do():
        out: Dict[str, Any] = {
            "base": base, "symbol": kc, "binance": bn,
            "price": None, "change_pct": None, "high": None, "low": None,
            "volume": None, "bid": None, "ask": None,
            "source": None, "ts": int(time.time()),
        }
        b = _binance_24h(base)
        if b and b.get("price"):
            out.update(b)
            out["source"] = "binance"
            return out
        k = _kucoin_stats(base)
        if k and k.get("price"):
            out.update(k)
            out["source"] = "kucoin"
            return out
        for src, fn in (("bybit", _bybit_price), ("okx", _okx_price), ("gate", _gate_price), ("mexc", _mexc_price), ("bitget", _bitget_price), ("htx", _htx_price), ("kraken", _kraken_price), ("coinbase", _coinbase_price), ("binance", _binance_price)):
            p = fn(base)
            if p:
                out["price"] = p
                out["source"] = src
                return out
        return out
    return _cached(f"tk:{base}", TTL_PX, _do)

def get_prices_batch(symbols: List[str]) -> Dict[str, float]:
    bases = []
    for s in symbols:
        b, _, _ = normalize_symbol(s)
        if b not in bases:
            bases.append(b)
    result: Dict[str, float] = {}
    def one(b):
        p = get_live_price(b)
        return b, p
    with ThreadPoolExecutor(max_workers=min(8, max(1, len(bases)))) as ex:
        futs = [ex.submit(one, b) for b in bases[:40]]
        for f in as_completed(futs):
            try:
                b, p = f.result()
                if p:
                    result[b] = p
                    result[f"{b}-USDT"] = p
                    result[f"{b}USDT"] = p
            except Exception:
                pass
    return result

KC_TF = {
    "1min": "1min", "5min": "5min", "15min": "15min", "30min": "30min",
    "1hour": "1hour", "4hour": "4hour", "1day": "1day", "1week": "1week",
    "1m": "1min", "5m": "5min", "15m": "15min", "1h": "1hour", "4h": "4hour", "1d": "1day",
}

def fetch_candles(symbol: str, tf: str = "1hour", start: int = 0, end: int = 0) -> List[Dict[str, float]]:
    base, kc, _ = normalize_symbol(symbol)
    interval = KC_TF.get(tf, "1hour")
    if not end:
        end = int(time.time())
    mult = {"1min": 60, "5min": 300, "15min": 900, "1hour": 3600, "4hour": 14400, "1day": 86400}.get(interval, 3600)
    if not start:
        start = end - 250 * mult
    key = f"cd:{base}:{interval}:{start//60}"
    def _do():
        url = f"https://api.kucoin.com/api/v1/market/candles?type={interval}&symbol={kc}&startAt={start}&endAt={end}"
        try:
            j = _json(url, 15)
            rows = j.get("data") or []
            out = []
            for r in rows:
                try:
                    out.append({
                        "time": int(r[0]), "open": float(r[1]), "close": float(r[2]),
                        "high": float(r[3]), "low": float(r[4]), "volume": float(r[5]),
                    })
                except Exception:
                    continue
            out.sort(key=lambda x: x["time"])
            return filter_closed_candles(out, interval)
        except Exception:
            return []
    return _cached(key, TTL_SLOW, _do)

def fetch_orderbook(symbol: str, depth: int = 20) -> Dict[str, Any]:
    base, kc, _ = normalize_symbol(symbol)
    depth = 20 if depth not in (20, 100) else depth
    def _do():
        try:
            j = _json(f"https://api.kucoin.com/api/v1/market/orderbook/level2_{depth}?symbol={kc}", 8)
            d = j.get("data") or {}
            return {"bids": d.get("bids") or [], "asks": d.get("asks") or [], "ts": int(time.time())}
        except Exception:
            return {"bids": [], "asks": [], "ts": int(time.time())}
    return _cached(f"ob:{base}:{depth}", TTL_PX, _do)

def funding_rate(base: str) -> Optional[float]:
    base, _, _ = normalize_symbol(base)
    fut = "XBTUSDTM" if base == "BTC" else f"{base}USDTM"
    def _do():
        try:
            j = _json(f"https://api-futures.kucoin.com/api/v1/funding-rate/{fut}/current", 8)
            d = j.get("data") or {}
            return float(d.get("value") or d.get("fundingRate") or 0)
        except Exception:
            return None
    return _cached(f"fr:{base}", TTL_SLOW, _do)

def open_interest(base: str) -> Optional[float]:
    base, _, _ = normalize_symbol(base)
    fut = "XBTUSDTM" if base == "BTC" else f"{base}USDTM"
    def _do():
        try:
            j = _json(f"https://api-futures.kucoin.com/api/v1/contracts/{fut}", 8)
            d = j.get("data") or {}
            return float(d.get("openInterest") or d.get("openInterestQty") or 0) or None
        except Exception:
            return None
    return _cached(f"oi:{base}", TTL_SLOW, _do)

def health_check() -> List[Dict[str, Any]]:
    tests = [
        ("Binance", "https://api.binance.com/api/v3/ping"),
        ("KuCoin", "https://api.kucoin.com/api/v1/status"),
        ("Bybit", "https://api.bybit.com/v5/market/time"),
        ("OKX", "https://www.okx.com/api/v5/public/time"),
        ("Gate", "https://api.gateio.ws/api/v4/spot/currency_pairs"),
    ]
    out = []
    for name, url in tests:
        t0 = time.time()
        ok, err = False, ""
        try:
            _get(url, 6)
            ok = True
        except Exception as e:
            err = str(e)[:100]
        out.append({"name": name, "ok": ok, "ms": int((time.time() - t0) * 1000), "error": err})
    return out

def rich_snapshot(symbol: str) -> Dict[str, Any]:
    base, kc, bn = normalize_symbol(symbol)
    t = get_ticker(base)
    book = fetch_orderbook(base)
    fr = funding_rate(base)
    oi = open_interest(base)
    bids = book.get("bids") or []
    asks = book.get("asks") or []
    spread = None
    try:
        if bids and asks:
            spread = (float(asks[0][0]) - float(bids[0][0])) / float(bids[0][0]) * 100
    except Exception:
        pass
    return {
        **t,
        "funding": fr,
        "open_interest": oi,
        "spread_pct": spread,
        "bid": float(bids[0][0]) if bids else t.get("bid"),
        "ask": float(asks[0][0]) if asks else t.get("ask"),
    }

POPULAR = [
    "BTC", "ETH", "SOL", "XRP", "DOGE", "ADA", "LINK", "AVAX", "DOT", "MATIC",
    "LTC", "BCH", "ATOM", "NEAR", "APT", "SUI", "ARB", "OP", "INJ", "TIA",
    "PEPE", "WIF", "BNB", "TON", "TRX", "SHIB", "FIL", "UNI", "AAVE", "FET",
]


def filter_closed_candles(candles, tf="1hour"):
    """Drop incomplete last candle based on timeframe seconds."""
    if not candles:
        return []
    mult = {"1min": 60, "5min": 300, "15min": 900, "30min": 1800, "1hour": 3600, "4hour": 14400, "1day": 86400}
    sec = mult.get(tf, 3600)
    now = int(time.time())
    out = []
    for c in candles:
        t = int(c.get("time") or 0)
        # keep candle if its period fully ended
        if t + sec <= now + 1:
            out.append(c)
    # if filter removed everything, keep all but last
    if len(out) < 10 and len(candles) > 10:
        return candles[:-1]
    return out or candles
