# -*- coding: utf-8 -*-
"""APEX storage v3 — free/locked margin, staged TP, fees, migration, alerts."""
from __future__ import annotations
import io
import json
import os
import sqlite3
import time
from typing import Any, Dict, List, Optional

FEE_RATE = 0.0006  # 0.06% each side

def _db_path() -> str:
    base = os.environ.get("APEX_DATA") or os.path.join(os.path.expanduser("~"), ".apex_native")
    os.makedirs(base, exist_ok=True)
    return os.path.join(base, "apex.db")

def conn() -> sqlite3.Connection:
    c = sqlite3.connect(_db_path(), check_same_thread=False)
    c.row_factory = sqlite3.Row
    return c

def _cols(c, table: str) -> set:
    return {r[1] for r in c.execute("PRAGMA table_info(%s)" % table).fetchall()}

def _add_col(c, table: str, col: str, decl: str):
    if col not in _cols(c, table):
        try:
            c.execute("ALTER TABLE %s ADD COLUMN %s %s" % (table, col, decl))
        except Exception:
            pass

def init_db() -> None:
    c = conn()
    c.executescript("""
    CREATE TABLE IF NOT EXISTS settings(key TEXT PRIMARY KEY, value TEXT);
    CREATE TABLE IF NOT EXISTS wallet(
      id INTEGER PRIMARY KEY CHECK(id=1),
      balance REAL, locked_margin REAL DEFAULT 0, equity REAL,
      realized_pnl REAL, total_deposited REAL, peak_equity REAL, fees_paid REAL
    );
    CREATE TABLE IF NOT EXISTS positions(
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      symbol TEXT, side TEXT, entry REAL, qty REAL, qty_open REAL,
      leverage REAL, margin REAL, margin_open REAL,
      tp1 REAL, tp2 REAL, tp3 REAL, sl REAL,
      tp1_done INTEGER DEFAULT 0, tp2_done INTEGER DEFAULT 0, tp3_done INTEGER DEFAULT 0,
      trail_pct REAL DEFAULT 0, trail_active INTEGER DEFAULT 0,
      peak_price REAL, status TEXT, opened_ts INTEGER,
      note TEXT DEFAULT '', source TEXT DEFAULT 'manual', tag TEXT DEFAULT ''
    );
    CREATE TABLE IF NOT EXISTS orders(
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      symbol TEXT, side TEXT, order_type TEXT, price REAL,
      leverage REAL, margin REAL, tp1 REAL, tp2 REAL, tp3 REAL, sl REAL,
      trail_pct REAL DEFAULT 0, status TEXT, created_ts INTEGER, note TEXT
    );
    CREATE TABLE IF NOT EXISTS trades(
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      pos_id INTEGER, symbol TEXT, side TEXT, entry REAL, exit REAL,
      qty REAL, leverage REAL, pnl REAL, pnl_pct REAL, fee REAL,
      reason TEXT, ts INTEGER
    );
    CREATE TABLE IF NOT EXISTS notes(
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      title TEXT, body TEXT, symbol TEXT, ts INTEGER
    );
    CREATE TABLE IF NOT EXISTS ledger(
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      type TEXT, amount REAL, balance_after REAL, locked_after REAL, note TEXT, ts INTEGER
    );
    CREATE TABLE IF NOT EXISTS chat_log(
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      role TEXT, content TEXT, model TEXT, ts INTEGER
    );
    CREATE TABLE IF NOT EXISTS watchlist(
      symbol TEXT PRIMARY KEY, added_ts INTEGER, note TEXT DEFAULT ''
    );
    CREATE TABLE IF NOT EXISTS alerts(
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      symbol TEXT, condition TEXT, price REAL, status TEXT, created_ts INTEGER, note TEXT
    );
    CREATE TABLE IF NOT EXISTS templates(
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT, side TEXT, leverage REAL, margin REAL,
      trail_pct REAL, note TEXT
    );
    """)
    # migrations for older DBs
    _add_col(c, "wallet", "locked_margin", "REAL DEFAULT 0")
    _add_col(c, "positions", "tp1_done", "INTEGER DEFAULT 0")
    _add_col(c, "positions", "tp2_done", "INTEGER DEFAULT 0")
    _add_col(c, "positions", "tp3_done", "INTEGER DEFAULT 0")
    _add_col(c, "positions", "peak_price", "REAL")
    _add_col(c, "positions", "trail_active", "INTEGER DEFAULT 0")
    _add_col(c, "positions", "tag", "TEXT DEFAULT ''")
    _add_col(c, "ledger", "locked_after", "REAL DEFAULT 0")
    if not c.execute("SELECT id FROM wallet WHERE id=1").fetchone():
        c.execute(
            "INSERT INTO wallet(id,balance,locked_margin,equity,realized_pnl,total_deposited,peak_equity,fees_paid) "
            "VALUES(1,100,0,100,0,100,100,0)"
        )
    # backfill locked from open positions if zero
    w = c.execute("SELECT balance, locked_margin FROM wallet WHERE id=1").fetchone()
    if w and float(w["locked_margin"] or 0) == 0:
        sm = c.execute(
            "SELECT COALESCE(SUM(margin_open),0) FROM positions WHERE status='open'"
        ).fetchone()[0]
        if sm and float(sm) > 0:
            c.execute("UPDATE wallet SET locked_margin=? WHERE id=1", (float(sm),))
    c.commit()
    c.close()

def get_setting(key: str, default: str = "") -> str:
    c = conn()
    r = c.execute("SELECT value FROM settings WHERE key=?", (key,)).fetchone()
    c.close()
    return r["value"] if r else default

def set_setting(key: str, value: str) -> None:
    c = conn()
    c.execute("INSERT OR REPLACE INTO settings(key,value) VALUES(?,?)", (key, str(value)))
    c.commit()
    c.close()

def set_secret(key: str, value: str) -> None:
    if not value:
        set_setting(key, "")
        return
    salt = "apex-native-v2"
    raw = value.encode("utf-8")
    out = bytes([b ^ ord(salt[i % len(salt)]) for i, b in enumerate(raw)])
    set_setting(key, "enc:" + out.hex())

def get_secret(key: str) -> str:
    v = get_setting(key, "")
    if not v:
        return ""
    if not v.startswith("enc:"):
        return v
    try:
        raw = bytes.fromhex(v[4:])
        salt = "apex-native-v2"
        return bytes([b ^ ord(salt[i % len(salt)]) for i, b in enumerate(raw)]).decode("utf-8")
    except Exception:
        return ""

def get_wallet() -> Dict[str, float]:
    c = conn()
    r = c.execute("SELECT * FROM wallet WHERE id=1").fetchone()
    c.close()
    d = dict(r) if r else {}
    bal = float(d.get("balance") or 0)
    locked = float(d.get("locked_margin") or 0)
    d["free_balance"] = bal  # cash free (not locked)
    d["locked_margin"] = locked
    d["total_equity_cash"] = bal + locked  # if balance is free only
    return d

def _wallet_row(c):
    return dict(c.execute("SELECT * FROM wallet WHERE id=1").fetchone())

def _ledger(c, typ: str, amount: float, bal: float, locked: float, note: str):
    c.execute(
        "INSERT INTO ledger(type,amount,balance_after,locked_after,note,ts) VALUES(?,?,?,?,?,?)",
        (typ, amount, bal, locked, note[:160], int(time.time())),
    )

def deposit(amount: float, note: str = "") -> Dict[str, float]:
    amount = float(amount)
    c = conn()
    w = _wallet_row(c)
    bal = float(w["balance"])
    locked = float(w.get("locked_margin") or 0)
    if amount < 0 and abs(amount) > bal + 1e-9:
        c.close()
        raise ValueError("برداشت بیشتر از موجودی آزاد مجاز نیست (آزاد: %.2f)" % bal)
    new_bal = bal + amount
    if new_bal < -1e-9:
        c.close()
        raise ValueError("موجودی آزاد نمی‌تواند منفی شود")
    dep = float(w["total_deposited"]) + (amount if amount > 0 else 0)
    peak = max(float(w["peak_equity"]), new_bal + locked)
    c.execute(
        "UPDATE wallet SET balance=?, equity=?, total_deposited=?, peak_equity=? WHERE id=1",
        (new_bal, new_bal + locked, dep, peak),
    )
    _ledger(c, "deposit" if amount >= 0 else "withdraw", amount, new_bal, locked, note)
    c.commit()
    c.close()
    return get_wallet()

def open_position(
    symbol: str, side: str, entry: float, leverage: float, margin: float,
    tp1=None, tp2=None, tp3=None, sl=None, note: str = "", source: str = "manual",
    trail_pct: float = 0.0, tag: str = "",
) -> Dict[str, Any]:
    side = (side or "").upper()
    if side not in ("LONG", "SHORT"):
        raise ValueError("سمت باید LONG یا SHORT باشد")
    entry = float(entry)
    leverage = max(1.0, min(125.0, float(leverage)))
    margin = float(margin)
    if margin <= 0 or entry <= 0:
        raise ValueError("مارجین و قیمت ورود باید بزرگ‌تر از صفر باشند")
    # daily loss limit
    try:
        lim = float(get_setting("pref_daily_loss", "0") or 0)
    except Exception:
        lim = 0.0
    if lim > 0:
        # sum today's realized
        start = int(time.time()) - 86400
        c0 = conn()
        day_pnl = c0.execute(
            "SELECT COALESCE(SUM(pnl),0) FROM trades WHERE ts>=?", (start,)
        ).fetchone()[0]
        c0.close()
        if float(day_pnl) <= -abs(lim):
            raise ValueError("حد ضرر روزانه فعال است (%.2f)" % lim)

    notional = margin * leverage
    qty = notional / entry
    entry_fee = notional * FEE_RATE
    c = conn()
    w = _wallet_row(c)
    bal = float(w["balance"])
    locked = float(w.get("locked_margin") or 0)
    open_n = c.execute("SELECT COUNT(*) FROM positions WHERE status='open'").fetchone()[0]
    if open_n >= 20:
        c.close()
        raise ValueError("حداکثر ۲۰ پوزیشن باز")
    need = margin + entry_fee
    if need > bal + 1e-9:
        c.close()
        raise ValueError("موجودی آزاد کافی نیست (نیاز %.2f / آزاد %.2f)" % (need, bal))
    new_bal = bal - need
    new_locked = locked + margin
    realized = float(w["realized_pnl"]) - entry_fee  # fee as cost
    fees = float(w["fees_paid"]) + entry_fee
    peak = max(float(w["peak_equity"]), new_bal + new_locked)
    c.execute(
        "UPDATE wallet SET balance=?, locked_margin=?, equity=?, realized_pnl=?, fees_paid=?, peak_equity=? WHERE id=1",
        (new_bal, new_locked, new_bal + new_locked, realized, fees, peak),
    )
    _ledger(c, "fee_open", -entry_fee, new_bal, new_locked, "entry fee %s" % symbol.upper())
    _ledger(c, "margin_lock", -margin, new_bal, new_locked, "lock %s" % symbol.upper())

    def f(x):
        return float(x) if x not in (None, "") else None

    cur = c.execute(
        """INSERT INTO positions(
            symbol,side,entry,qty,qty_open,leverage,margin,margin_open,
            tp1,tp2,tp3,sl,tp1_done,tp2_done,tp3_done,trail_pct,trail_active,peak_price,
            status,opened_ts,note,source,tag)
           VALUES(?,?,?,?,?,?,?,?,?,?,?,?,0,0,0,?,0,?, 'open',?,?,?,?)""",
        (
            symbol.upper(), side, entry, qty, qty, leverage, margin, margin,
            f(tp1), f(tp2), f(tp3), f(sl), float(trail_pct or 0), entry,
            int(time.time()), note[:200], source, tag[:40],
        ),
    )
    pid = cur.lastrowid
    c.commit()
    c.close()
    return {
        "id": pid, "symbol": symbol.upper(), "side": side, "entry": entry,
        "qty": qty, "margin": margin, "leverage": leverage, "notional": notional,
        "entry_fee": entry_fee, "free_balance": new_bal, "locked_margin": new_locked,
    }

def place_order(
    symbol: str, side: str, order_type: str, price: float,
    leverage: float, margin: float, tp1=None, tp2=None, tp3=None, sl=None,
    trail_pct: float = 0.0, note: str = "",
) -> Dict[str, Any]:
    order_type = (order_type or "market").lower()
    if order_type in ("بازار", "market"):
        order_type = "market"
    elif order_type in ("حد", "limit"):
        order_type = "limit"
    elif order_type in ("حد ضرر", "stop", "stop_limit"):
        order_type = "stop"
    else:
        order_type = "market"
    if order_type == "market":
        return open_position(
            symbol, side, price, leverage, margin,
            tp1=tp1, tp2=tp2, tp3=tp3, sl=sl, note=note, trail_pct=trail_pct, source="manual",
        )
    margin = float(margin)
    c = conn()
    w = _wallet_row(c)
    bal = float(w["balance"])
    locked = float(w.get("locked_margin") or 0)
    # reserve margin only (fee on fill)
    if margin > bal:
        c.close()
        raise ValueError("موجودی آزاد کافی نیست برای رزرو سفارش")
    new_bal = bal - margin
    new_locked = locked + margin
    c.execute(
        "UPDATE wallet SET balance=?, locked_margin=?, equity=? WHERE id=1",
        (new_bal, new_locked, new_bal + new_locked),
    )
    _ledger(c, "order_reserve", -margin, new_bal, new_locked, "order %s" % symbol.upper())

    def f(x):
        return float(x) if x not in (None, "") else None

    cur = c.execute(
        """INSERT INTO orders(symbol,side,order_type,price,leverage,margin,tp1,tp2,tp3,sl,trail_pct,status,created_ts,note)
           VALUES(?,?,?,?,?,?,?,?,?,?,?,'open',?,?)""",
        (
            symbol.upper(), side.upper(), order_type, float(price), float(leverage), margin,
            f(tp1), f(tp2), f(tp3), f(sl), float(trail_pct or 0), int(time.time()), note[:120],
        ),
    )
    oid = cur.lastrowid
    c.commit()
    c.close()
    return {"id": oid, "status": "open", "order_type": order_type, "reserved_margin": margin}

def list_open_orders() -> List[Dict[str, Any]]:
    c = conn()
    rows = c.execute("SELECT * FROM orders WHERE status='open' ORDER BY id DESC").fetchall()
    c.close()
    return [dict(r) for r in rows]

def cancel_order(oid: int) -> None:
    c = conn()
    o = c.execute("SELECT * FROM orders WHERE id=? AND status='open'", (oid,)).fetchone()
    if not o:
        c.close()
        raise ValueError("سفارش باز یافت نشد")
    o = dict(o)
    w = _wallet_row(c)
    bal = float(w["balance"]) + float(o["margin"])
    locked = max(0.0, float(w.get("locked_margin") or 0) - float(o["margin"]))
    c.execute(
        "UPDATE wallet SET balance=?, locked_margin=?, equity=? WHERE id=1",
        (bal, locked, bal + locked),
    )
    c.execute("UPDATE orders SET status='cancelled' WHERE id=?", (oid,))
    _ledger(c, "order_cancel", float(o["margin"]), bal, locked, "cancel #%s" % oid)
    c.commit()
    c.close()

def process_pending_orders(price_map: Dict[str, float]) -> List[str]:
    events = []
    for o in list_open_orders():
        sym = o["symbol"]
        base = sym.replace("-USDT", "").replace("USDT", "")
        px = price_map.get(sym) or price_map.get(base)
        if not px:
            continue
        px = float(px)
        target = float(o["price"])
        side = o["side"]
        otype = o["order_type"]
        fill = False
        if otype == "limit":
            if side == "LONG" and px <= target:
                fill = True
            if side == "SHORT" and px >= target:
                fill = True
        elif otype == "stop":
            if side == "LONG" and px >= target:
                fill = True
            if side == "SHORT" and px <= target:
                fill = True
        if not fill:
            continue
        # margin already locked from order — open pos without re-locking margin
        entry = px
        leverage = float(o["leverage"])
        margin = float(o["margin"])
        qty = (margin * leverage) / entry
        notional = margin * leverage
        fee = notional * FEE_RATE
        c = conn()
        w = _wallet_row(c)
        bal = float(w["balance"]) - fee
        locked = float(w.get("locked_margin") or 0)  # already includes order margin
        if bal < -1e-9:
            c.close()
            continue
        fees = float(w["fees_paid"]) + fee
        realized = float(w["realized_pnl"]) - fee
        c.execute(
            "UPDATE wallet SET balance=?, equity=?, fees_paid=?, realized_pnl=? WHERE id=1",
            (bal, bal + locked, fees, realized),
        )
        c.execute(
            """INSERT INTO positions(
                symbol,side,entry,qty,qty_open,leverage,margin,margin_open,
                tp1,tp2,tp3,sl,tp1_done,tp2_done,tp3_done,trail_pct,trail_active,peak_price,
                status,opened_ts,note,source,tag)
               VALUES(?,?,?,?,?,?,?,?,?,?,?,?,0,0,0,?,0,?, 'open',?,?,?,?)""",
            (
                sym, side, entry, qty, qty, leverage, margin, margin,
                o["tp1"], o["tp2"], o["tp3"], o["sl"], float(o["trail_pct"] or 0), entry,
                int(time.time()), "from_order_%s" % o["id"], "order", "",
            ),
        )
        c.execute("UPDATE orders SET status='filled' WHERE id=?", (o["id"],))
        _ledger(c, "fee_open", -fee, bal, locked, "fill order #%s" % o["id"])
        c.commit()
        c.close()
        events.append("ORDER#%s filled %s %s @ %.4f" % (o["id"], side, sym, entry))
    return events

def list_open_positions() -> List[Dict[str, Any]]:
    c = conn()
    rows = c.execute("SELECT * FROM positions WHERE status='open' ORDER BY id DESC").fetchall()
    c.close()
    return [dict(r) for r in rows]

def position_pnl(pos: Dict[str, Any], price: float) -> Dict[str, float]:
    price = float(price)
    entry = float(pos["entry"])
    qty = float(pos["qty_open"])
    side = pos["side"]
    if side == "LONG":
        pnl = (price - entry) * qty
    else:
        pnl = (entry - price) * qty
    notional = entry * qty
    pnl_pct = (pnl / notional * 100) if notional else 0.0
    margin = float(pos.get("margin_open") or pos.get("margin") or 1)
    roe = pnl / margin * 100 if margin else 0.0
    return {"pnl": pnl, "pnl_pct": pnl_pct, "roe": roe, "notional": notional}

def close_position(pid: int, price: float, qty_pct: float = 100.0, reason: str = "MANUAL") -> Dict[str, Any]:
    price = float(price)
    qty_pct = max(1.0, min(100.0, float(qty_pct)))
    c = conn()
    p = c.execute("SELECT * FROM positions WHERE id=? AND status='open'", (pid,)).fetchone()
    if not p:
        c.close()
        raise ValueError("پوزیشن باز پیدا نشد")
    p = dict(p)
    qty_open = float(p["qty_open"])
    close_qty = qty_open * (qty_pct / 100.0)
    if close_qty <= 0:
        c.close()
        raise ValueError("مقدار بستن نامعتبر")
    entry = float(p["entry"])
    side = p["side"]
    if side == "LONG":
        pnl = (price - entry) * close_qty
    else:
        pnl = (entry - price) * close_qty
    fee = abs(price * close_qty) * FEE_RATE
    net = pnl - fee
    notional = entry * close_qty
    pnl_pct = (pnl / notional * 100) if notional else 0.0
    margin_open = float(p["margin_open"] if p["margin_open"] is not None else p["margin"])
    margin_back = margin_open * (close_qty / qty_open)
    w = _wallet_row(c)
    bal = float(w["balance"]) + margin_back + net
    locked = max(0.0, float(w.get("locked_margin") or 0) - margin_back)
    realized = float(w["realized_pnl"]) + net
    fees = float(w["fees_paid"]) + fee
    peak = max(float(w["peak_equity"]), bal + locked)
    c.execute(
        "UPDATE wallet SET balance=?, locked_margin=?, equity=?, realized_pnl=?, fees_paid=?, peak_equity=? WHERE id=1",
        (bal, locked, bal + locked, realized, fees, peak),
    )
    new_qty = qty_open - close_qty
    new_margin = margin_open - margin_back
    if new_qty <= 1e-12 or qty_pct >= 99.999:
        c.execute("UPDATE positions SET qty_open=0, margin_open=0, status='closed' WHERE id=?", (pid,))
    else:
        c.execute(
            "UPDATE positions SET qty_open=?, margin_open=? WHERE id=?",
            (new_qty, new_margin, pid),
        )
    c.execute(
        """INSERT INTO trades(pos_id,symbol,side,entry,exit,qty,leverage,pnl,pnl_pct,fee,reason,ts)
           VALUES(?,?,?,?,?,?,?,?,?,?,?,?)""",
        (pid, p["symbol"], side, entry, price, close_qty, p["leverage"], net, pnl_pct, fee, reason, int(time.time())),
    )
    _ledger(c, "fee_close", -fee, bal, locked, reason)
    _ledger(c, "margin_unlock", margin_back, bal, locked, "close #%s" % pid)
    if abs(net) > 1e-12:
        _ledger(c, "pnl", net, bal, locked, reason)
    c.commit()
    c.close()
    return {"pnl": net, "pnl_pct": pnl_pct, "fee": fee, "qty": close_qty}

def _update_pos(pid: int, **fields):
    if not fields:
        return
    keys = []
    vals = []
    for k, v in fields.items():
        keys.append("%s=?" % k)
        vals.append(v)
    vals.append(pid)
    c = conn()
    c.execute("UPDATE positions SET %s WHERE id=?" % ",".join(keys), vals)
    c.commit()
    c.close()

def apply_tp_sl_trail(price_map: Dict[str, float]) -> List[str]:
    """Staged TP (TP1 40%, TP2 30%, TP3 rest), real trailing SL, liquidation."""
    events = []
    for p in list_open_positions():
        sym = p["symbol"]
        base = sym.replace("-USDT", "").replace("USDT", "")
        price = price_map.get(sym) or price_map.get(base)
        if not price:
            continue
        price = float(price)
        side = p["side"]
        entry = float(p["entry"])
        sl = p.get("sl")
        trail = float(p.get("trail_pct") or 0)
        peak = p.get("peak_price")
        peak = float(peak) if peak is not None else entry

        if side == "LONG" and price > peak:
            peak = price
            _update_pos(p["id"], peak_price=peak)
        if side == "SHORT" and price < peak:
            peak = price
            _update_pos(p["id"], peak_price=peak)

        if trail > 0:
            u = position_pnl(p, price)
            if u["pnl_pct"] >= trail or int(p.get("trail_active") or 0) == 1:
                if side == "LONG":
                    new_sl = peak * (1.0 - trail / 100.0)
                    floor = max(entry, float(sl) if sl is not None else 0)
                    if new_sl > floor:
                        _update_pos(p["id"], sl=new_sl, peak_price=peak, trail_active=1)
                        sl = new_sl
                        events.append("TRAIL-SL #%s -> %.4f" % (p["id"], new_sl))
                else:
                    new_sl = peak * (1.0 + trail / 100.0)
                    if sl is None or new_sl < float(sl):
                        _update_pos(p["id"], sl=new_sl, peak_price=peak, trail_active=1)
                        sl = new_sl
                        events.append("TRAIL-SL #%s -> %.4f" % (p["id"], new_sl))

        u = position_pnl(p, price)
        margin = float(p.get("margin_open") or p.get("margin") or 0)
        if margin > 0 and u["pnl"] <= -0.9 * margin:
            close_position(p["id"], price, 100, "LIQUIDATION")
            events.append("LIQ #%s %s" % (p["id"], sym))
            continue

        if sl is not None:
            slv = float(sl)
            hit = (side == "LONG" and price <= slv) or (side == "SHORT" and price >= slv)
            if hit:
                close_position(p["id"], price, 100, "SL")
                events.append("SL #%s %s" % (p["id"], sym))
                continue

        # staged TP
        for level, flag, pct, reason in (
            ("tp1", "tp1_done", 40.0, "TP1"),
            ("tp2", "tp2_done", 30.0, "TP2"),
            ("tp3", "tp3_done", 100.0, "TP3"),
        ):
            if int(p.get(flag) or 0) == 1:
                continue
            tp = p.get(level)
            if tp is None:
                continue
            tpv = float(tp)
            hit = (side == "LONG" and price >= tpv) or (side == "SHORT" and price <= tpv)
            if not hit:
                continue
            # refresh pos after previous partial
            cur = [x for x in list_open_positions() if x["id"] == p["id"]]
            if not cur:
                break
            close_position(p["id"], price, pct, reason)
            _update_pos(p["id"], **{flag: 1})
            events.append("%s #%s %s %.0f%%" % (reason, p["id"], sym, pct))
            p = cur[0]
            p[flag] = 1
            if reason == "TP3" or pct >= 99:
                break
    return events

# --- watchlist / alerts / templates ---
def watchlist_add(symbol: str, note: str = "") -> None:
    base = symbol.upper().replace("-USDT", "").replace("USDT", "")
    c = conn()
    c.execute(
        "INSERT OR REPLACE INTO watchlist(symbol,added_ts,note) VALUES(?,?,?)",
        (base, int(time.time()), note[:80]),
    )
    c.commit()
    c.close()

def watchlist_list() -> List[Dict[str, Any]]:
    c = conn()
    rows = c.execute("SELECT * FROM watchlist ORDER BY added_ts DESC").fetchall()
    c.close()
    return [dict(r) for r in rows]

def watchlist_remove(symbol: str) -> None:
    base = symbol.upper().replace("-USDT", "").replace("USDT", "")
    c = conn()
    c.execute("DELETE FROM watchlist WHERE symbol=?", (base,))
    c.commit()
    c.close()

def alert_add(symbol: str, condition: str, price: float, note: str = "") -> int:
    condition = condition if condition in ("above", "below", "بالا", "پایین") else "above"
    if condition == "بالا":
        condition = "above"
    if condition == "پایین":
        condition = "below"
    c = conn()
    cur = c.execute(
        "INSERT INTO alerts(symbol,condition,price,status,created_ts,note) VALUES(?,?,?,'open',?,?)",
        (symbol.upper(), condition, float(price), int(time.time()), note[:80]),
    )
    oid = cur.lastrowid
    c.commit()
    c.close()
    return oid

def alerts_open() -> List[Dict[str, Any]]:
    c = conn()
    rows = c.execute("SELECT * FROM alerts WHERE status='open' ORDER BY id DESC").fetchall()
    c.close()
    return [dict(r) for r in rows]

def process_alerts(price_map: Dict[str, float]) -> List[str]:
    ev = []
    for a in alerts_open():
        base = a["symbol"].replace("-USDT", "").replace("USDT", "")
        px = price_map.get(a["symbol"]) or price_map.get(base)
        if not px:
            continue
        px = float(px)
        hit = (a["condition"] == "above" and px >= float(a["price"])) or (
            a["condition"] == "below" and px <= float(a["price"])
        )
        if hit:
            c = conn()
            c.execute("UPDATE alerts SET status='triggered' WHERE id=?", (a["id"],))
            c.commit()
            c.close()
            ev.append("ALERT %s %s %s" % (a["symbol"], a["condition"], a["price"]))
    return ev

def template_save(name: str, side: str, leverage: float, margin: float, trail_pct: float = 0) -> None:
    c = conn()
    c.execute(
        "INSERT INTO templates(name,side,leverage,margin,trail_pct,note) VALUES(?,?,?,?,?,?)",
        (name[:40], side.upper(), float(leverage), float(margin), float(trail_pct), ""),
    )
    c.commit()
    c.close()

def templates_list() -> List[Dict[str, Any]]:
    c = conn()
    rows = c.execute("SELECT * FROM templates ORDER BY id DESC LIMIT 20").fetchall()
    c.close()
    return [dict(r) for r in rows]

def risk_size(balance: float, risk_pct: float, entry: float, sl: float, leverage: float = 1) -> Dict[str, float]:
    """Position size from risk percent and SL distance (Persian risk calc)."""
    balance = float(balance)
    risk_pct = max(0.1, min(10.0, float(risk_pct)))
    entry = float(entry)
    sl = float(sl)
    leverage = max(1.0, float(leverage))
    risk_usd = balance * (risk_pct / 100.0)
    dist = abs(entry - sl) / entry if entry else 0
    if dist < 1e-8:
        return {"error": 1, "margin": 0, "qty": 0, "risk_usd": risk_usd}
    notional = risk_usd / dist
    margin = notional / leverage
    qty = notional / entry
    return {"risk_usd": risk_usd, "notional": notional, "margin": margin, "qty": qty, "sl_pct": dist * 100}

def add_note(title: str, body: str, symbol: str = "") -> None:
    c = conn()
    c.execute(
        "INSERT INTO notes(title,body,symbol,ts) VALUES(?,?,?,?)",
        (title[:80], body[:4000], symbol[:20], int(time.time())),
    )
    c.commit()
    c.close()

def list_notes(limit: int = 50) -> List[Dict[str, Any]]:
    c = conn()
    rows = c.execute("SELECT * FROM notes ORDER BY id DESC LIMIT ?", (limit,)).fetchall()
    c.close()
    return [dict(r) for r in rows]

def list_trades(limit: int = 100) -> List[Dict[str, Any]]:
    c = conn()
    rows = c.execute("SELECT * FROM trades ORDER BY id DESC LIMIT ?", (limit,)).fetchall()
    c.close()
    return [dict(r) for r in rows]

def list_ledger(limit: int = 100) -> List[Dict[str, Any]]:
    c = conn()
    rows = c.execute("SELECT * FROM ledger ORDER BY id DESC LIMIT ?", (limit,)).fetchall()
    c.close()
    return [dict(r) for r in rows]

def add_chat(role: str, content: str, model: str = "") -> None:
    c = conn()
    c.execute(
        "INSERT INTO chat_log(role,content,model,ts) VALUES(?,?,?,?)",
        (role, content[:20000], model[:40], int(time.time())),
    )
    c.commit()
    c.close()

def list_chat(limit: int = 40) -> List[Dict[str, Any]]:
    c = conn()
    rows = c.execute("SELECT * FROM chat_log ORDER BY id DESC LIMIT ?", (limit,)).fetchall()
    c.close()
    return [dict(r) for r in reversed(list(rows))]

def portfolio_stats(price_map: Optional[Dict[str, float]] = None) -> Dict[str, Any]:
    price_map = price_map or {}
    w = get_wallet()
    positions = list_open_positions()
    trades = list_trades(500)
    upnl = 0.0
    margin_used = float(w.get("locked_margin") or 0)
    pos_rows = []
    for p in positions:
        sym = p["symbol"]
        base = sym.replace("-USDT", "").replace("USDT", "")
        px = price_map.get(sym) or price_map.get(base)
        row = dict(p)
        if px:
            u = position_pnl(p, float(px))
            row.update({"live_price": float(px), **u})
            upnl += u["pnl"]
        else:
            row.update({"live_price": None, "pnl": None, "pnl_pct": None, "roe": None})
        pos_rows.append(row)
    wins = [t for t in trades if (t.get("pnl") or 0) > 0]
    losses = [t for t in trades if (t.get("pnl") or 0) < 0]
    gross_win = sum(float(t["pnl"]) for t in wins)
    gross_loss = abs(sum(float(t["pnl"]) for t in losses))
    profit_factor = (gross_win / gross_loss) if gross_loss > 1e-12 else None
    bal = float(w.get("balance") or 0)
    equity = bal + margin_used + upnl
    deposited = float(w.get("total_deposited") or 0) or 100.0
    roi = (equity - deposited) / deposited * 100.0
    peak = float(w.get("peak_equity") or equity)
    dd = ((peak - equity) / peak * 100.0) if peak > 0 else 0.0
    return {
        "wallet": w,
        "balance": bal,
        "free_balance": bal,
        "locked_margin": margin_used,
        "equity": equity,
        "unrealized": upnl,
        "realized_pnl": float(w.get("realized_pnl") or 0),
        "margin_used": margin_used,
        "free_margin": bal,
        "open_count": len(positions),
        "positions": pos_rows,
        "trade_count": len(trades),
        "wins": len(wins),
        "losses": len(losses),
        "winrate": (len(wins) / len(trades) * 100.0) if trades else 0.0,
        "profit_factor": profit_factor,
        "avg_win": (gross_win / len(wins)) if wins else 0.0,
        "avg_loss": (gross_loss / len(losses)) if losses else 0.0,
        "fees_paid": float(w.get("fees_paid") or 0),
        "total_deposited": deposited,
        "roi_pct": roi,
        "peak_equity": peak,
        "drawdown_pct": dd,
        "orders_open": len(list_open_orders()),
    }

def export_report_csv(price_map: Optional[Dict[str, float]] = None) -> str:
    st = portfolio_stats(price_map or {})
    buf = io.StringIO()
    buf.write("APEX_PORTFOLIO_REPORT\n")
    buf.write("generated_ts,%s\n" % int(time.time()))
    buf.write("\n=== SUMMARY ===\n")
    for k in (
        "balance", "free_balance", "locked_margin", "equity", "unrealized", "realized_pnl",
        "margin_used", "open_count", "trade_count", "wins", "losses", "winrate",
        "profit_factor", "fees_paid", "roi_pct", "drawdown_pct", "orders_open",
    ):
        buf.write("%s,%s\n" % (k, st.get(k)))
    buf.write("\n=== OPEN_POSITIONS ===\n")
    buf.write("id,symbol,side,entry,live,qty,margin,pnl,roe,tp1_done,tp2_done,source\n")
    for p in st["positions"]:
        buf.write("%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s\n" % (
            p.get("id"), p.get("symbol"), p.get("side"), p.get("entry"), p.get("live_price"),
            p.get("qty_open"), p.get("margin_open"), p.get("pnl"), p.get("roe"),
            p.get("tp1_done"), p.get("tp2_done"), p.get("source"),
        ))
    buf.write("\n=== TRADES ===\n")
    trades = list_trades(500)
    if trades:
        keys = list(trades[0].keys())
        buf.write(",".join(keys) + "\n")
        for t in trades:
            buf.write(",".join(str(t.get(k, "")) for k in keys) + "\n")
    buf.write("\n=== LEDGER ===\n")
    for L in list_ledger(200):
        buf.write("%s\n" % json.dumps(dict(L), ensure_ascii=False))
    return buf.getvalue()

def export_report_json(price_map: Optional[Dict[str, float]] = None) -> str:
    st = portfolio_stats(price_map or {})
    st["trades"] = list_trades(500)
    st["ledger"] = list_ledger(200)
    st["orders"] = list_open_orders()
    st["watchlist"] = watchlist_list()
    st["alerts"] = alerts_open()
    st["generated_ts"] = int(time.time())
    return json.dumps(st, ensure_ascii=False, indent=2)

def equity_with_marks(price_map: Dict[str, float]) -> Dict[str, float]:
    st = portfolio_stats(price_map)
    return {
        "balance": st["balance"],
        "unrealized": st["unrealized"],
        "equity": st["equity"],
        "realized_pnl": st["realized_pnl"],
        "total_deposited": st["total_deposited"],
        "margin_used": st["margin_used"],
        "free_balance": st["free_balance"],
        "locked_margin": st["locked_margin"],
        "winrate": st["winrate"],
        "roi_pct": st["roi_pct"],
        "drawdown_pct": st["drawdown_pct"],
        "open_count": st["open_count"],
    }


def reverse_position(pid: int, price: float) -> Dict[str, Any]:
    """Close full position and open opposite with same margin."""
    c = conn()
    p = c.execute("SELECT * FROM positions WHERE id=? AND status='open'", (pid,)).fetchone()
    c.close()
    if not p:
        raise ValueError("پوزیشن باز نیست")
    p = dict(p)
    close_position(pid, float(price), 100, "REVERSE")
    side = "SHORT" if p["side"] == "LONG" else "LONG"
    margin = float(p.get("margin") or p.get("margin_open") or 0)
    return open_position(
        p["symbol"], side, float(price), float(p["leverage"]), margin,
        source="reverse", note="rev#%s" % pid,
    )

def close_all_positions(price_map: Dict[str, float]) -> List[str]:
    ev = []
    for p in list_open_positions():
        sym = p["symbol"]
        base = sym.replace("-USDT", "").replace("USDT", "")
        px = price_map.get(sym) or price_map.get(base)
        if not px:
            continue
        try:
            r = close_position(p["id"], float(px), 100, "CLOSE_ALL")
            ev.append("CLOSE_ALL #%s pnl=%.2f" % (p["id"], r["pnl"]))
        except Exception as e:
            ev.append("FAIL #%s %s" % (p["id"], e))
    return ev
