# -*- coding: utf-8 -*-
"""Core market analysis — indicators + structured signal (no UI)."""
from __future__ import annotations
from typing import Any, Dict, List, Optional
from apex import market_apis as mapi

def _sma(xs, n):
    out = [None] * len(xs)
    s = 0.0
    for i, v in enumerate(xs):
        s += v
        if i >= n:
            s -= xs[i - n]
        if i >= n - 1:
            out[i] = s / n
    return out

def _ema(xs, n):
    out = [None] * len(xs)
    if not xs or n <= 0:
        return out
    k = 2.0 / (n + 1)
    ema = None
    for i, v in enumerate(xs):
        if i < n - 1:
            continue
        if ema is None:
            ema = sum(xs[i - n + 1:i + 1]) / n
        else:
            ema = v * k + ema * (1 - k)
        out[i] = ema
    return out

def _rsi(closes, n=14):
    out = [None] * len(closes)
    if len(closes) < n + 1:
        return out
    gains, losses = [], []
    for i in range(1, len(closes)):
        d = closes[i] - closes[i - 1]
        gains.append(max(d, 0.0))
        losses.append(max(-d, 0.0))
    ag = sum(gains[:n]) / n
    al = sum(losses[:n]) / n
    for i in range(n, len(gains)):
        ag = (ag * (n - 1) + gains[i]) / n
        al = (al * (n - 1) + losses[i]) / n
        rs = (ag / al) if al > 1e-12 else 100.0
        out[i + 1] = 100.0 - (100.0 / (1.0 + rs))
    return out

def _atr(candles, n=14):
    trs = []
    for i, c in enumerate(candles):
        h, l = float(c["high"]), float(c["low"])
        if i == 0:
            trs.append(h - l)
        else:
            pc = float(candles[i - 1]["close"])
            trs.append(max(h - l, abs(h - pc), abs(l - pc)))
    return _sma(trs, n)

def analyze_candles(candles):
    if not candles or len(candles) < 30:
        return {"ok": False, "error": "candle data insufficient (min 30)"}
    closes = [float(c["close"]) for c in candles]
    last = closes[-1]
    ema9 = _ema(closes, 9)
    ema21 = _ema(closes, 21)
    ema50 = _ema(closes, 50)
    rsi = _rsi(closes, 14)
    atr = _atr(candles, 14)
    e9, e21, e50 = ema9[-1], ema21[-1], ema50[-1]
    r = rsi[-1]
    a = atr[-1]
    score = 0.0
    reasons = []
    if e9 and e21:
        if e9 > e21:
            score += 0.25
            reasons.append("EMA9>EMA21")
        else:
            score -= 0.25
            reasons.append("EMA9<EMA21")
    if e21 and e50:
        if e21 > e50:
            score += 0.25
            reasons.append("mid trend up")
        else:
            score -= 0.25
            reasons.append("mid trend down")
    if r is not None:
        if r < 30:
            score += 0.2
            reasons.append("RSI oversold")
        elif r > 70:
            score -= 0.2
            reasons.append("RSI overbought")
    if len(closes) >= 6:
        mom = (closes[-1] / closes[-6] - 1) * 100
        if mom > 1:
            score += 0.15
            reasons.append("short momentum up")
        elif mom < -1:
            score -= 0.15
            reasons.append("short momentum down")
    score = max(-1.0, min(1.0, score))
    if score > 0.2:
        side = "LONG"
    elif score < -0.2:
        side = "SHORT"
    else:
        side = "NEUTRAL"
    atr_v = float(a or last * 0.01)
    if side == "LONG":
        entry, sl = last, last - 1.5 * atr_v
        tp1, tp2, tp3 = last + 1.5 * atr_v, last + 2.5 * atr_v, last + 4.0 * atr_v
    elif side == "SHORT":
        entry, sl = last, last + 1.5 * atr_v
        tp1, tp2, tp3 = last - 1.5 * atr_v, last - 2.5 * atr_v, last - 4.0 * atr_v
    else:
        entry, sl, tp1, tp2, tp3 = last, None, None, None, None
    risk = abs(entry - sl) if sl else None
    reward = abs(tp1 - entry) if tp1 and entry else None
    rr = (reward / risk) if risk and reward and risk > 0 else None
    conviction = int(max(1, min(10, round(abs(score) * 10))))
    return {
        "ok": True, "side": side, "entry": entry, "sl": sl,
        "tp1": tp1, "tp2": tp2, "tp3": tp3, "rsi": r, "atr": a,
        "ema9": e9, "ema21": e21, "ema50": e50, "score": score,
        "conviction": conviction, "rr": rr, "reasons": reasons,
        "price": last, "bars": len(candles),
    }

def full_symbol_analysis(symbol, tf="1hour"):
    snap = mapi.rich_snapshot(symbol)
    candles = mapi.fetch_candles(symbol, tf)
    try:
        candles = mapi.filter_closed_candles(candles, tf)
    except Exception:
        pass
    ind = analyze_candles(candles)
    if ind.get("ok") and snap.get("price"):
        live = float(snap["price"])
        close = float(ind.get("price") or live)
        if close > 0 and abs(live / close - 1) < 0.05 and ind.get("side") in ("LONG", "SHORT"):
            scale = live / close
            for k in ("entry", "sl", "tp1", "tp2", "tp3"):
                if ind.get(k) is not None:
                    ind[k] = float(ind[k]) * scale
            ind["price"] = live
    return {"symbol": symbol, "tf": tf, "snapshot": snap, "analysis": ind, "ts": snap.get("ts")}

def format_analysis_fa(result):
    a = result.get("analysis") or {}
    s = result.get("snapshot") or {}
    if not a.get("ok"):
        return a.get("error") or "analysis failed"
    side = a.get("side")
    side_fa = {"LONG": "LONG", "SHORT": "SHORT", "NEUTRAL": "NEUTRAL"}.get(side, side)
    lines = [
        "=== APEX CORE ANALYSIS ===",
        "symbol: %s tf: %s" % (result.get("symbol"), result.get("tf")),
        "live: %s (%s)" % (s.get("price"), s.get("source")),
        "24h: %s funding: %s" % (s.get("change_pct"), s.get("funding")),
        "side: %s conv: %s/10 score: %.2f" % (side_fa, a.get("conviction"), a.get("score") or 0),
        "entry: %s sl: %s" % (a.get("entry"), a.get("sl")),
        "tp1/2/3: %s | %s | %s" % (a.get("tp1"), a.get("tp2"), a.get("tp3")),
        "RSI: %s ATR: %s RR: %s" % (a.get("rsi"), a.get("atr"), a.get("rr")),
        "reasons:",
    ]
    for r in a.get("reasons") or []:
        lines.append(" - " + str(r))
    return "\n".join(lines)

def signal_dict_for_trade(result):
    a = result.get("analysis") or {}
    if not a.get("ok") or a.get("side") not in ("LONG", "SHORT"):
        return None
    return {
        "side": a["side"], "entry": a.get("entry"), "sl": a.get("sl"),
        "tp1": a.get("tp1"), "tp2": a.get("tp2"), "tp3": a.get("tp3"),
        "conviction": a.get("conviction"), "rr": a.get("rr"),
    }


def full_symbol_analysis_flex(symbol, tfs=None, learning=None, min_conviction=1):
    """Flexible multi-timeframe analysis + optional learning bias."""
    tfs = tfs or ["15min", "1hour", "4hour"]
    results = {}
    scores = []
    for tf in tfs:
        try:
            r = full_symbol_analysis(symbol, tf)
            results[tf] = r
            a = (r.get("analysis") or {})
            if a.get("ok"):
                sc = float(a.get("score") or 0)
                scores.append(sc)
        except Exception as e:
            results[tf] = {"error": str(e)}
    # primary = 1hour if present else first ok
    primary = results.get("1hour") or next((results[t] for t in tfs if (results.get(t) or {}).get("analysis", {}).get("ok")), None)
    if not primary:
        return {"ok": False, "error": "no tf data", "tfs": results}
    a = dict(primary.get("analysis") or {})
    avg = sum(scores) / len(scores) if scores else 0.0
    align = 0
    sides = []
    for t, r in results.items():
        aa = (r.get("analysis") or {})
        if aa.get("side") in ("LONG", "SHORT"):
            sides.append(aa["side"])
    if sides:
        long_n = sides.count("LONG")
        short_n = sides.count("SHORT")
        if long_n > short_n:
            align = long_n / len(sides)
            mtf_side = "LONG"
        elif short_n > long_n:
            align = short_n / len(sides)
            mtf_side = "SHORT"
        else:
            mtf_side = "NEUTRAL"
            align = 0.5
    else:
        mtf_side = a.get("side") or "NEUTRAL"
    # blend score with mtf
    blended = avg
    if learning and learning.get("ok"):
        pref = learning.get("prefer_side")
        if pref and mtf_side == pref:
            blended += 0.1
        worst = set(learning.get("worst_symbols") or [])
        sym_u = (symbol or "").upper()
        if any(sym_u in w or w.startswith(sym_u) for w in worst):
            blended -= 0.15
            a.setdefault("reasons", []).append("learning: weak symbol historically")
        best = set(learning.get("best_symbols") or [])
        if any(sym_u in b or b.startswith(sym_u) for b in best):
            blended += 0.1
            a.setdefault("reasons", []).append("learning: stronger symbol historically")
    blended = max(-1.0, min(1.0, blended))
    if blended > 0.2:
        final_side = "LONG"
    elif blended < -0.2:
        final_side = "SHORT"
    else:
        final_side = "NEUTRAL"
    # if single-tf conflict with mtf majority, prefer majority when align high
    if align >= 0.66 and mtf_side in ("LONG", "SHORT"):
        final_side = mtf_side
    a["side"] = final_side
    a["score"] = blended
    a["conviction"] = int(max(1, min(10, round(abs(blended) * 10))))
    a["mtf_align"] = align
    a["mtf_side"] = mtf_side
    if a["conviction"] < min_conviction and final_side != "NEUTRAL":
        a["side"] = "NEUTRAL"
        a.setdefault("reasons", []).append("below min conviction filter")
    primary = dict(primary)
    primary["analysis"] = a
    primary["tf_results"] = {t: (results[t].get("analysis") or {}).get("side") for t in results}
    primary["ok"] = True
    return primary
