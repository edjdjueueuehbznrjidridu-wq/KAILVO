# -*- coding: utf-8 -*-
"""Trade learning engine — learn from closed positions / trades."""
from __future__ import annotations
from collections import defaultdict
from typing import Any, Dict, List
from apex import storage as db

def _safe_div(a, b):
    return a / b if b else 0.0

def learn_from_history(limit: int = 300) -> Dict[str, Any]:
    trades = db.list_trades(limit)
    if not trades:
        return {
            "ok": False,
            "message": "هنوز معامله بسته‌ای برای یادگیری نیست",
            "tips": ["چند معامله دمو باز و بسته کن تا الگو ساخته شود"],
            "by_side": {},
            "by_symbol": {},
            "by_reason": {},
            "best_symbols": [],
            "worst_symbols": [],
            "prefer_side": None,
            "avg_win": 0,
            "avg_loss": 0,
            "winrate": 0,
            "sample": 0,
        }

    by_side = defaultdict(lambda: {"n": 0, "wins": 0, "pnl": 0.0})
    by_sym = defaultdict(lambda: {"n": 0, "wins": 0, "pnl": 0.0})
    by_reason = defaultdict(lambda: {"n": 0, "wins": 0, "pnl": 0.0})
    total_pnl = 0.0
    wins = 0
    win_pnls, loss_pnls = [], []

    for t in trades:
        side = (t.get("side") or "?").upper()
        sym = (t.get("symbol") or "?").upper()
        reason = (t.get("reason") or "NA")
        pnl = float(t.get("pnl") or 0)
        total_pnl += pnl
        is_win = pnl > 0
        if is_win:
            wins += 1
            win_pnls.append(pnl)
        else:
            loss_pnls.append(pnl)
        for bag, key in ((by_side, side), (by_sym, sym), (by_reason, reason)):
            bag[key]["n"] += 1
            bag[key]["pnl"] += pnl
            if is_win:
                bag[key]["wins"] += 1

    n = len(trades)
    winrate = wins / n * 100.0
    avg_win = _safe_div(sum(win_pnls), len(win_pnls))
    avg_loss = _safe_div(sum(loss_pnls), len(loss_pnls))

    def enrich(bag):
        out = {}
        for k, v in bag.items():
            out[k] = {
                **v,
                "winrate": _safe_div(v["wins"], v["n"]) * 100.0,
                "avg_pnl": _safe_div(v["pnl"], v["n"]),
            }
        return out

    by_side_e = enrich(by_side)
    by_sym_e = enrich(by_sym)
    by_reason_e = enrich(by_reason)

    # ranking symbols with at least 2 trades
    ranked = sorted(
        [(k, v) for k, v in by_sym_e.items() if v["n"] >= 2],
        key=lambda x: (x[1]["avg_pnl"], x[1]["winrate"]),
        reverse=True,
    )
    best = [k for k, _ in ranked[:5]]
    worst = [k for k, _ in ranked[-5:]] if ranked else []

    prefer_side = None
    if by_side_e:
        prefer_side = max(by_side_e.items(), key=lambda x: x[1]["avg_pnl"])[0]

    tips = []
    if winrate < 40 and n >= 5:
        tips.append("نرخ برد زیر ۴۰٪ است — سایز مارجین را کم کن و فقط سیگنال با قدرت ≥۶ بگیر")
    if avg_loss and abs(avg_loss) > (avg_win * 1.5 if avg_win else 1):
        tips.append("میانگین ضرر از میانگین سود بزرگ‌تر است — حد ضرر را نزدیک‌تر یا R:R را بالاتر ببر")
    if prefer_side:
        tips.append("از تاریخچه، سمت %s میانگین بهتری داشته" % prefer_side)
    if best:
        tips.append("نمادهای نسبتاً بهتر: " + ", ".join(best[:3]))
    if worst and worst != best:
        tips.append("نمادهای ضعیف‌تر: " + ", ".join(worst[:3]))
    sl_stats = by_reason_e.get("SL") or by_reason_e.get("sl")
    if sl_stats and sl_stats["n"] >= 3 and sl_stats["winrate"] < 20:
        tips.append("بسیاری از خروج‌ها با SL بوده — ورود یا تریل را بازبینی کن")
    if not tips:
        tips.append("نمونه کافی یا متعادل است — ادامه بده با ریسک ثابت")

    return {
        "ok": True,
        "sample": n,
        "total_pnl": total_pnl,
        "winrate": winrate,
        "avg_win": avg_win,
        "avg_loss": avg_loss,
        "by_side": by_side_e,
        "by_symbol": by_sym_e,
        "by_reason": by_reason_e,
        "best_symbols": best,
        "worst_symbols": worst,
        "prefer_side": prefer_side,
        "tips": tips,
        "message": "یادگیری از %d معامله" % n,
    }

def format_learning_fa(L: Dict[str, Any]) -> str:
    if not L.get("ok"):
        return L.get("message") or "بدون داده"
    lines = [
        "=== موتور یادگیری معاملات ===",
        "نمونه: %d | Winrate: %.1f%% | PnL کل: %.2f" % (L["sample"], L["winrate"], L["total_pnl"]),
        "میانگین سود: %.2f | میانگین ضرر: %.2f" % (L["avg_win"], L["avg_loss"]),
        "سمت ترجیحی: %s" % (L.get("prefer_side") or "—"),
        "بهترین نمادها: %s" % (", ".join(L.get("best_symbols") or []) or "—"),
        "ضعیف‌تر: %s" % (", ".join(L.get("worst_symbols") or []) or "—"),
        "نکات:",
    ]
    for t in L.get("tips") or []:
        lines.append(" - " + t)
    return "\n".join(lines)

def ai_context_from_learning(L: Dict[str, Any]) -> str:
    if not L.get("ok"):
        return "No trade history yet."
    return (
        "Trader history: n=%d winrate=%.1f%% prefer_side=%s best=%s worst=%s tips=%s"
        % (
            L["sample"], L["winrate"], L.get("prefer_side"),
            L.get("best_symbols"), L.get("worst_symbols"),
            "; ".join(L.get("tips") or [])[:300],
        )
    )
