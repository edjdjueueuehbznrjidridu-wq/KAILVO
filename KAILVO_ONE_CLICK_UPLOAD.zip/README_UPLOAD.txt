KAILVO — آپلود ساده
===================
اگر فقط ZIP پروژه را آپلود کردی، باید این workflow هم باشد:

مسیر فایل workflow روی گیت‌هاب:
.github/workflows/build-apk.yml

راحت‌ترین راه:
1) همین پوشه ONE_CLICK را extract کن
2) هر دو را آپلود کن:
   - APEX_SUPER_GitHub_Ready.zip
   - پوشه .github (با فایل workflow داخلش)
